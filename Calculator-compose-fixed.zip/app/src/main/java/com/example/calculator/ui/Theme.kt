package com.example.calculator.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Colors taken from the design mockup.
val Surface1 = Color(0xFF1A1A1A)        // digit keys, header buttons
val Surface2 = Color(0xFF2A2A2A)        // AC, ±, %
val SurfaceTabs = Color(0xFF111111)     // segmented control track, operator tint base
val TabSelected = Color(0xFF262626)
val TabUnselected = Color(0xFF8E8E8E)
val SciKey = Color(0xFF161616)          // scientific function keys
val DisplayBg = Color(0xFFFFC40D)
val DisplayInk = Color(0xFF17120A)
val EqualsInk = Color(0xFF140A0E)

/** The accent options listed in the design's props: pink (default), blue, amber, teal. */
val Accents = listOf(
    Color(0xFFFF8FB1),
    Color(0xFF4DA3FF),
    Color(0xFFF5B92E),
    Color(0xFF3FD8D0),
)

@Composable
fun CalculatorTheme(content: @Composable () -> Unit) {
    // The design is dark-only, so we always use the dark scheme.
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Color.Black,
            surface = Color.Black,
            surfaceContainer = Surface1,
            onBackground = Color.White,
            onSurface = Color.White,
        ),
        content = content,
    )
}

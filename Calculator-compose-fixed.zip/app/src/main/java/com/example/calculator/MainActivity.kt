package com.example.calculator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.calculator.ui.Accents
import com.example.calculator.ui.CalculatorScreen
import com.example.calculator.ui.CalculatorTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )

        val prefs = getSharedPreferences("calculator", MODE_PRIVATE)

        setContent {
            CalculatorTheme {
                val viewModel: CalculatorViewModel = viewModel()
                var accentIndex by rememberSaveable {
                    mutableIntStateOf(prefs.getInt("accent", 0).coerceIn(0, Accents.lastIndex))
                }
                var scientific by rememberSaveable {
                    mutableStateOf(prefs.getBoolean("scientific", false))
                }

                CalculatorScreen(
                    state = viewModel.state,
                    scientific = scientific,
                    accentIndex = accentIndex,
                    onScientificChange = {
                        scientific = it
                        prefs.edit().putBoolean("scientific", it).apply()
                    },
                    onAccentChange = {
                        accentIndex = it
                        prefs.edit().putInt("accent", it).apply()
                    },
                    onKey = viewModel::onKey,
                    onUseHistory = viewModel::useHistory,
                    onClearHistory = viewModel::clearHistory,
                )
            }
        }
    }
}

package com.example.calculator.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.BaselineShift
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import com.example.calculator.CalculatorState
import com.example.calculator.HistoryEntry
import com.example.calculator.Key
import com.example.calculator.formatForDisplay

// ---------------------------------------------------------------- layout specs

private enum class Kind { Function, Digit, Operator, Equals, Sci, SciAccent }

private class Spec(
    val label: AnnotatedString,
    val key: Key,
    val kind: Kind,
    val description: String? = null,
    val small: Boolean = false, // AC uses a smaller font than ± and %
    val span: Int = 1,
)

private class PadStyle(
    val columns: Int,
    val rowHeight: Dp,
    val gap: Dp,
    val radius: Dp,
    val digitSp: TextUnit,
    val smallSp: TextUnit,
    val funcSp: TextUnit,
    val opSp: TextUnit,
    val equalsSp: TextUnit,
)

// Standard pad: 4 columns, 76dp rows, 12dp gaps, 26dp radius.
private val StandardPad = PadStyle(4, 76.dp, 12.dp, 26.dp, 30.sp, 22.sp, 26.sp, 34.sp, 36.sp)

// Scientific pad: same keys, tighter: 62dp rows, 10dp gaps, 24dp radius.
private val ScientificPad = PadStyle(4, 62.dp, 10.dp, 24.dp, 28.sp, 20.sp, 24.sp, 32.sp, 34.sp)

// Extra function grid above the scientific pad: 5 columns, 40dp rows, 8dp gaps, 16dp radius.
private val SciGrid = PadStyle(5, 40.dp, 8.dp, 16.dp, 16.sp, 16.sp, 16.sp, 16.sp, 16.sp)

private fun t(text: String) = AnnotatedString(text)

private fun digit(n: Int) = Spec(t(n.toString()), Key.entries[n], Kind.Digit)

private val KeypadRows: List<List<Spec>> = listOf(
    listOf(
        Spec(t("AC"), Key.AC, Kind.Function, "All clear", small = true),
        Spec(t("±"), Key.SIGN, Kind.Function, "Plus minus"),
        Spec(t("%"), Key.PERCENT, Kind.Function, "Percent"),
        Spec(t("÷"), Key.DIV, Kind.Operator, "Divide"),
    ),
    listOf(digit(7), digit(8), digit(9), Spec(t("×"), Key.MUL, Kind.Operator, "Multiply")),
    listOf(digit(4), digit(5), digit(6), Spec(t("−"), Key.SUB, Kind.Operator, "Subtract")),
    listOf(digit(1), digit(2), digit(3), Spec(t("+"), Key.ADD, Kind.Operator, "Add")),
    listOf(
        Spec(t("0"), Key.D0, Kind.Digit, span = 2),
        Spec(t("."), Key.DOT, Kind.Digit, "Decimal point"),
        Spec(t("="), Key.EQUALS, Kind.Equals, "Equals"),
    ),
)

private val PowerLabel = buildAnnotatedString {
    append("x")
    withStyle(SpanStyle(baselineShift = BaselineShift.Superscript, fontSize = 11.sp)) { append("y") }
}

private fun sciRows(degrees: Boolean): List<List<Spec>> = listOf(
    listOf(
        Spec(t("("), Key.LPAREN, Kind.Sci, "Open bracket"),
        Spec(t(")"), Key.RPAREN, Kind.Sci, "Close bracket"),
        Spec(t("x²"), Key.SQUARE, Kind.Sci, "Square"),
        Spec(t("√"), Key.SQRT, Kind.Sci, "Square root"),
        Spec(PowerLabel, Key.POWER, Kind.Sci, "Power"),
    ),
    listOf(
        Spec(t("sin"), Key.SIN, Kind.Sci),
        Spec(t("cos"), Key.COS, Kind.Sci),
        Spec(t("tan"), Key.TAN, Kind.Sci),
        Spec(t("ln"), Key.LN, Kind.Sci, "Natural log"),
        Spec(t("log"), Key.LOG, Kind.Sci, "Log base 10"),
    ),
    listOf(
        Spec(t("π"), Key.PI, Kind.Sci, "Pi"),
        Spec(t("e"), Key.E, Kind.Sci, "Euler number"),
        Spec(t("1/x"), Key.RECIPROCAL, Kind.Sci, "Reciprocal"),
        Spec(t("n!"), Key.FACTORIAL, Kind.Sci, "Factorial"),
        Spec(
            t(if (degrees) "Deg" else "Rad"),
            Key.ANGLE,
            Kind.SciAccent,
            if (degrees) "Angle mode, degrees" else "Angle mode, radians",
        ),
    ),
)

// ---------------------------------------------------------------------- icons

private const val MENU_ICON = "M4 7h16M4 12h16M4 17h10"
private val HISTORY_ICON = listOf("M3 12a9 9 0 1 0 3-6.7L3 8", "M3 3v5h5", "M12 7v5l3 2")
private const val CLOSE_ICON = "M6.5 6.5l11 11M17.5 6.5l-11 11"

/** Draws stroked SVG paths authored on a 24x24 viewBox, exactly like the mockup's icons. */
@Composable
private fun SvgIcon(paths: List<String>, iconSize: Dp, strokeWidth: Float, color: Color) {
    val parsed: List<Path> = remember(paths) {
        paths.map { PathParser().parsePathString(it).toPath() }
    }
    Canvas(Modifier.size(iconSize)) {
        val k = this.size.width / 24f
        withTransform({ scale(scaleX = k, scaleY = k, pivot = Offset.Zero) }) {
            parsed.forEach { path ->
                drawPath(
                    path = path,
                    color = color,
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round, join = StrokeJoin.Round),
                )
            }
        }
    }
}

@Composable
private fun CircleIconButton(
    diameter: Dp,
    background: Color,
    description: String,
    onClick: () -> Unit,
    content: @Composable () -> Unit,
) {
    Box(
        modifier = Modifier
            .size(diameter)
            .clip(CircleShape)
            .background(background)
            .clickable(role = Role.Button, onClick = onClick)
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center,
    ) { content() }
}

// --------------------------------------------------------------------- screen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalculatorScreen(
    state: CalculatorState,
    scientific: Boolean,
    accentIndex: Int,
    onScientificChange: (Boolean) -> Unit,
    onAccentChange: (Int) -> Unit,
    onKey: (Key) -> Unit,
    onUseHistory: (HistoryEntry) -> Unit,
    onClearHistory: () -> Unit,
) {
    val accent = Accents[accentIndex]
    // CSS: color-mix(in srgb, accent 16%, #111111)
    val opBg = lerp(SurfaceTabs, accent, 0.16f)
    val fontFamily = rememberOutfit()

    var showHistory by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }

    CompositionLocalProvider(LocalTextStyle provides TextStyle(fontFamily = fontFamily)) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color.Black)
                .windowInsetsPadding(WindowInsets.safeDrawing),
        ) {
            BoxWithConstraints(
                Modifier
                    .fillMaxSize()
                    .padding(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 12.dp),
            ) {
                // On short screens shrink the key rows a little so the display keeps some room.
                val pad = if (scientific) ScientificPad else StandardPad
                val fixedChrome = 44.dp + 12.dp + 38.dp + 32.dp + (if (scientific) 12.dp else 0.dp)
                val gridHeight =
                    if (scientific) {
                        SciGrid.rowHeight * 3 + SciGrid.gap * 2 + ScientificPad.rowHeight * 5 + ScientificPad.gap * 4
                    } else {
                        StandardPad.rowHeight * 5 + StandardPad.gap * 4
                    }
                val scale = ((maxHeight - fixedChrome - 150.dp) / gridHeight).coerceIn(0.72f, 1f)

                Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Header(
                        accentIndex = accentIndex,
                        showMenu = showMenu,
                        onMenuToggle = { showMenu = it },
                        onAccentChange = onAccentChange,
                        onHistory = { showHistory = true },
                    )

                    ModeTabs(scientific = scientific, onChange = onScientificChange)

                    DisplayCard(
                        state = state,
                        scientific = scientific,
                        onDelete = { onKey(Key.DEL) },
                        modifier = Modifier.weight(1f),
                    )

                    if (scientific) {
                        PadGrid(
                            rows = sciRows(state.degrees),
                            style = SciGrid,
                            heightScale = scale,
                            accent = accent,
                            opBg = opBg,
                            onKey = onKey,
                        )
                        Box(Modifier.height(12.dp))
                    }

                    PadGrid(
                        rows = KeypadRows,
                        style = pad,
                        heightScale = scale,
                        accent = accent,
                        opBg = opBg,
                        onKey = onKey,
                    )
                }
            }
        }

        if (showHistory) {
            ModalBottomSheet(
                onDismissRequest = { showHistory = false },
                containerColor = SurfaceTabs,
                contentColor = Color.White,
            ) {
                HistoryContent(
                    history = state.history,
                    accent = accent,
                    onPick = {
                        onUseHistory(it)
                        showHistory = false
                    },
                    onClear = onClearHistory,
                )
            }
        }
    }
}

@Composable
private fun Header(
    accentIndex: Int,
    showMenu: Boolean,
    onMenuToggle: (Boolean) -> Unit,
    onAccentChange: (Int) -> Unit,
    onHistory: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(44.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box {
            CircleIconButton(44.dp, Surface1, "Menu", onClick = { onMenuToggle(true) }) {
                SvgIcon(listOf(MENU_ICON), 22.dp, 2f, Color.White)
            }
            DropdownMenu(expanded = showMenu, onDismissRequest = { onMenuToggle(false) }) {
                Text(
                    "Accent color",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = TabUnselected,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                )
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Accents.forEachIndexed { index, color ->
                        Box(
                            Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(color)
                                .then(
                                    if (index == accentIndex) Modifier.border(2.dp, Color.White, CircleShape)
                                    else Modifier,
                                )
                                .clickable(role = Role.Button) {
                                    onAccentChange(index)
                                    onMenuToggle(false)
                                },
                        )
                    }
                }
            }
        }

        Text(
            text = "Calculator",
            fontSize = 22.sp,
            fontWeight = FontWeight.Medium,
            letterSpacing = (-0.01).em,
            color = Color.White,
        )

        CircleIconButton(44.dp, Surface1, "History", onClick = onHistory) {
            SvgIcon(HISTORY_ICON, 22.dp, 2f, Color.White)
        }
    }
}

@Composable
private fun ModeTabs(scientific: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .padding(top = 12.dp)
            .clip(RoundedCornerShape(19.dp))
            .background(SurfaceTabs)
            .padding(3.dp),
    ) {
        ModeTab("Standard", selected = !scientific) { onChange(false) }
        ModeTab("Scientific", selected = scientific) { onChange(true) }
    }
}

@Composable
private fun ModeTab(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .height(32.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(if (selected) TabSelected else Color.Transparent)
            .clickable(role = Role.Tab, onClick = onClick)
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            color = if (selected) Color.White else TabUnselected,
        )
    }
}

@Composable
private fun DisplayCard(
    state: CalculatorState,
    scientific: Boolean,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier = modifier
            .padding(vertical = 16.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(32.dp))
            .background(DisplayBg)
            .padding(20.dp),
        horizontalAlignment = Alignment.End,
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        CircleIconButton(40.dp, Color.Black.copy(alpha = 0.12f), "Delete last digit", onDelete) {
            SvgIcon(listOf(CLOSE_ICON), 20.dp, 2.4f, DisplayInk)
        }

        Column(horizontalAlignment = Alignment.End) {
            val secondary = state.secondaryText
            if (secondary.isNotEmpty()) {
                Text(
                    text = secondary,
                    fontSize = 20.sp,
                    color = DisplayInk.copy(alpha = 0.6f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.End,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            AutoSizeText(
                text = state.mainText,
                maxSize = if (scientific) 56f else 76f,
                minSize = 28f,
                color = DisplayInk,
            )
        }
    }
}

/**
 * Single-line text that shrinks from [maxSize] down to [minSize] to fit the width.
 * Below the minimum it wraps onto up to three lines instead of overflowing.
 */
@Composable
private fun AutoSizeText(text: String, maxSize: Float, minSize: Float, color: Color) {
    val measurer = rememberTextMeasurer()
    val base = LocalTextStyle.current.copy(fontWeight = FontWeight.Medium, letterSpacing = (-0.03).em)

    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val widthPx = constraints.maxWidth
        val size = remember(text, widthPx, maxSize, base) {
            var s = maxSize
            while (s > minSize &&
                measurer.measure(
                    text = text,
                    style = base.copy(fontSize = s.sp),
                    softWrap = false,
                    maxLines = 1,
                ).size.width > widthPx
            ) {
                s = maxOf(minSize, s * 0.92f)
            }
            s
        }
        Text(
            text = text,
            color = color,
            fontSize = size.sp,
            lineHeight = (size * 1.05f).sp,
            fontWeight = FontWeight.Medium,
            letterSpacing = (-0.03).em,
            textAlign = TextAlign.End,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

// ---------------------------------------------------------------------- keypad

@Composable
private fun PadGrid(
    rows: List<List<Spec>>,
    style: PadStyle,
    heightScale: Float,
    accent: Color,
    opBg: Color,
    onKey: (Key) -> Unit,
) {
    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val cell = (maxWidth - style.gap * (style.columns - 1)) / style.columns
        Column(verticalArrangement = Arrangement.spacedBy(style.gap)) {
            rows.forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(style.gap)) {
                    row.forEach { spec ->
                        // A key spanning two columns also covers the gap between them (CSS grid span).
                        val width = cell * spec.span + style.gap * (spec.span - 1)
                        PadButton(
                            spec = spec,
                            style = style,
                            accent = accent,
                            opBg = opBg,
                            modifier = Modifier
                                .width(width)
                                .height(style.rowHeight * heightScale),
                            onKey = onKey,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PadButton(
    spec: Spec,
    style: PadStyle,
    accent: Color,
    opBg: Color,
    modifier: Modifier,
    onKey: (Key) -> Unit,
) {
    val background: Color
    val foreground: Color
    val fontSize: TextUnit
    val weight: FontWeight
    when (spec.kind) {
        Kind.Function -> {
            background = Surface2
            foreground = Color.White
            fontSize = if (spec.small) style.smallSp else style.funcSp
            weight = if (spec.small) FontWeight.Medium else FontWeight.Normal
        }
        Kind.Digit -> {
            background = Surface1
            foreground = Color.White
            fontSize = style.digitSp
            weight = FontWeight.Normal
        }
        Kind.Operator -> {
            background = opBg
            foreground = accent
            fontSize = style.opSp
            weight = FontWeight.Normal
        }
        Kind.Equals -> {
            background = accent
            foreground = EqualsInk
            fontSize = style.equalsSp
            weight = FontWeight.Medium
        }
        Kind.Sci -> {
            background = SciKey
            foreground = Color.White
            fontSize = style.digitSp
            weight = FontWeight.Medium
        }
        Kind.SciAccent -> {
            background = opBg
            foreground = accent
            fontSize = style.digitSp
            weight = FontWeight.Medium
        }
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(style.radius))
            .background(background)
            .clickable(role = Role.Button) { onKey(spec.key) }
            .then(
                if (spec.description != null) Modifier.semantics { contentDescription = spec.description }
                else Modifier,
            ),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = spec.label,
            color = foreground,
            fontSize = fontSize,
            fontWeight = weight,
            maxLines = 1,
        )
    }
}

// --------------------------------------------------------------------- history

@Composable
private fun HistoryContent(
    history: List<HistoryEntry>,
    accent: Color,
    onPick: (HistoryEntry) -> Unit,
    onClear: () -> Unit,
) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .navigationBarsPadding()
            .padding(bottom = 16.dp),
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("History", fontSize = 22.sp, fontWeight = FontWeight.Medium, color = Color.White)
            if (history.isNotEmpty()) {
                TextButton(onClick = onClear) { Text("Clear", color = accent, fontSize = 16.sp) }
            }
        }

        if (history.isEmpty()) {
            Text(
                "No calculations yet",
                color = TabUnselected,
                fontSize = 16.sp,
                modifier = Modifier.padding(vertical = 24.dp),
            )
        } else {
            LazyColumn(Modifier.heightIn(max = 420.dp)) {
                items(history) { entry ->
                    Column(Modifier.fillMaxWidth()) {
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .clickable(role = Role.Button) { onPick(entry) }
                                .padding(vertical = 12.dp),
                            horizontalAlignment = Alignment.End,
                        ) {
                            Text(
                                formatForDisplay(entry.expression) + " =",
                                color = TabUnselected,
                                fontSize = 16.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(
                                formatForDisplay(entry.result),
                                color = Color.White,
                                fontSize = 30.sp,
                                fontWeight = FontWeight.Medium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .height(1.dp)
                                .background(Surface1),
                        )
                    }
                }
            }
        }
    }
}

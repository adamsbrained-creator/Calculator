package com.example.calculator

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel

class CalculatorViewModel : ViewModel() {

    var state by mutableStateOf(CalculatorState())
        private set

    fun onKey(key: Key) {
        state = state.press(key)
    }

    /** Puts a history result back on the display so the user can keep calculating with it. */
    fun useHistory(entry: HistoryEntry) {
        state = state.copy(
            expression = entry.result,
            lastExpression = entry.expression,
            justEvaluated = true,
            error = false,
        )
    }

    fun clearHistory() {
        state = state.copy(history = emptyList())
    }
}

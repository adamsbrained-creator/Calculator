package com.example.calculator.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontVariation
import androidx.compose.ui.text.font.FontWeight

/**
 * The design uses the Outfit typeface. If a variable font file named `outfit.ttf` exists in
 * app/src/main/res/font/ it is used (weights 300–600); otherwise this falls back to the system
 * sans-serif so the project builds either way. The GitHub workflow downloads the file for you.
 */
@OptIn(ExperimentalTextApi::class)
@Composable
fun rememberOutfit(): FontFamily {
    val context = LocalContext.current
    return remember(context) {
        val resId = context.resources.getIdentifier("outfit", "font", context.packageName)
        if (resId == 0) {
            FontFamily.Default
        } else {
            FontFamily(
                listOf(300, 400, 500, 600).map { weight ->
                    Font(
                        resId = resId,
                        weight = FontWeight(weight),
                        style = FontStyle.Normal,
                        variationSettings = FontVariation.Settings(FontVariation.weight(weight)),
                    )
                },
            )
        }
    }
}

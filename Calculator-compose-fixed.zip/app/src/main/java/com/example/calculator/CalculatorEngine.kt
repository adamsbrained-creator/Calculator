package com.example.calculator

import java.math.BigDecimal
import java.math.MathContext
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/**
 * Evaluates the expression strings built by the keypad, e.g. "2×(3+4)−sin(30)".
 *
 * Supported: + − × ÷ ^, brackets (unclosed ones are closed automatically),
 * implicit multiplication ("2(3)", "2π"), sin cos tan ln log √, π, e, postfix ! and %.
 */
object Evaluator {

    /** Returns null when the expression is invalid or the result is not a finite number. */
    fun evaluate(expression: String, degrees: Boolean): Double? {
        return try {
            val value = Parser(tokenize(expression), degrees).parse()
            if (value.isNaN() || value.isInfinite()) null else value
        } catch (e: Exception) {
            null
        }
    }

    /** Formats a result with up to 12 significant digits; very large/small values use E notation. */
    fun format(value: Double): String {
        if (value == 0.0) return "0"
        val magnitude = abs(value)
        val text = if (magnitude >= 1e15 || magnitude < 1e-9) {
            val raw = String.format(Locale.US, "%.9E", value) // e.g. -1.234567890E+20
            val parts = raw.split('E')
            val mantissa = parts[0].trimEnd('0').trimEnd('.')
            mantissa + "E" + parts[1].toInt()
        } else {
            BigDecimal(value).round(MathContext(12)).stripTrailingZeros().toPlainString()
        }
        return if (text.startsWith("-")) "−" + text.substring(1) else text
    }

    // ---------------------------------------------------------------- tokenizer

    private enum class T { NUM, OP, LP, RP, FUNC, BANG, PCT }

    private class Token(val type: T, val text: String = "", val value: Double = 0.0)

    private val functionNames = listOf("sin", "cos", "tan", "log", "ln")

    private fun tokenize(s: String): List<Token> {
        val out = ArrayList<Token>()
        var i = 0
        while (i < s.length) {
            val c = s[i]
            when {
                c.isWhitespace() -> i++
                c.isDigit() || c == '.' -> {
                    var j = i
                    while (j < s.length && (s[j].isDigit() || s[j] == '.')) j++
                    // exponent produced by our own formatter, e.g. 1.5E20 or 2E-10
                    if (j < s.length && s[j] == 'E') {
                        var k = j + 1
                        if (k < s.length && (s[k] == '+' || s[k] == '-')) k++
                        if (k < s.length && s[k].isDigit()) {
                            while (k < s.length && s[k].isDigit()) k++
                            j = k
                        }
                    }
                    val text = s.substring(i, j)
                    out.add(Token(T.NUM, text, text.toDouble()))
                    i = j
                }
                c == '+' || c == '×' || c == '÷' || c == '^' -> {
                    out.add(Token(T.OP, c.toString()))
                    i++
                }
                c == '−' || c == '-' -> {
                    out.add(Token(T.OP, "−"))
                    i++
                }
                c == '(' -> {
                    out.add(Token(T.LP))
                    i++
                }
                c == ')' -> {
                    out.add(Token(T.RP))
                    i++
                }
                c == '!' -> {
                    out.add(Token(T.BANG))
                    i++
                }
                c == '%' -> {
                    out.add(Token(T.PCT))
                    i++
                }
                c == 'π' -> {
                    out.add(Token(T.NUM, "π", PI))
                    i++
                }
                c == '√' -> {
                    out.add(Token(T.FUNC, "√"))
                    i++
                }
                else -> {
                    val name = functionNames.firstOrNull { s.startsWith(it, i) }
                    if (name != null) {
                        out.add(Token(T.FUNC, name))
                        i += name.length
                    } else if (c == 'e') {
                        out.add(Token(T.NUM, "e", Math.E))
                        i++
                    } else {
                        throw IllegalArgumentException("Unexpected character: $c")
                    }
                }
            }
        }
        return out
    }

    // ------------------------------------------------------------------- parser

    private class Parser(private val tokens: List<Token>, private val degrees: Boolean) {
        private var pos = 0

        private fun peek(): Token? = tokens.getOrNull(pos)

        private fun next(): Token {
            val t = tokens.getOrNull(pos) ?: throw IllegalArgumentException("Unexpected end")
            pos++
            return t
        }

        private fun isOp(t: Token?, op: String): Boolean =
            t != null && t.type == T.OP && t.text == op

        fun parse(): Double {
            val v = parseExpression()
            if (pos != tokens.size) throw IllegalArgumentException("Unexpected token")
            return v
        }

        // expression := term (('+' | '−') term)*
        private fun parseExpression(): Double {
            var v = parseTerm()
            while (true) {
                val t = peek()
                if (isOp(t, "+")) {
                    pos++
                    v += parseTerm()
                } else if (isOp(t, "−")) {
                    pos++
                    v -= parseTerm()
                } else {
                    break
                }
            }
            return v
        }

        // term := unary (('×' | '÷' | implicit) unary)*
        private fun parseTerm(): Double {
            var v = parseUnary()
            while (true) {
                val t = peek()
                if (isOp(t, "×")) {
                    pos++
                    v *= parseUnary()
                } else if (isOp(t, "÷")) {
                    pos++
                    val d = parseUnary()
                    if (d == 0.0) throw ArithmeticException("Division by zero")
                    v /= d
                } else if (t != null && (t.type == T.NUM || t.type == T.LP || t.type == T.FUNC)) {
                    v *= parseUnary() // implicit multiplication
                } else {
                    break
                }
            }
            return v
        }

        // unary := ('−' | '+') unary | power
        private fun parseUnary(): Double {
            val t = peek()
            if (isOp(t, "−")) {
                pos++
                return -parseUnary()
            }
            if (isOp(t, "+")) {
                pos++
                return parseUnary()
            }
            return parsePower()
        }

        // power := postfix ('^' unary)?   (right associative, so 2^3^2 = 2^9)
        private fun parsePower(): Double {
            val base = parsePostfix()
            if (isOp(peek(), "^")) {
                pos++
                return base.pow(parseUnary())
            }
            return base
        }

        // postfix := primary ('!' | '%')*
        private fun parsePostfix(): Double {
            var v = parsePrimary()
            while (true) {
                val t = peek() ?: break
                if (t.type == T.BANG) {
                    pos++
                    v = factorial(v)
                } else if (t.type == T.PCT) {
                    pos++
                    v /= 100.0
                } else {
                    break
                }
            }
            return v
        }

        private fun parsePrimary(): Double {
            val t = next()
            return when (t.type) {
                T.NUM -> t.value
                T.LP -> parseGroup()
                T.FUNC -> applyFunction(t.text, parseArgument())
                else -> throw IllegalArgumentException("Unexpected token")
            }
        }

        // Called after '(' was consumed. A missing ')' at the very end is tolerated.
        private fun parseGroup(): Double {
            val v = parseExpression()
            val t = peek()
            if (t != null) {
                if (t.type == T.RP) pos++ else throw IllegalArgumentException("Expected )")
            }
            return v
        }

        private fun parseArgument(): Double {
            val t = peek()
            if (t != null && t.type == T.LP) {
                pos++
                return parseGroup()
            }
            return parsePostfix()
        }

        private fun toRadians(a: Double): Double = if (degrees) a * PI / 180.0 else a

        private fun clean(v: Double): Double = if (abs(v) < 1e-12) 0.0 else v

        private fun applyFunction(name: String, a: Double): Double {
            return when (name) {
                "sin" -> clean(sin(toRadians(a)))
                "cos" -> clean(cos(toRadians(a)))
                "tan" -> {
                    if (abs(cos(toRadians(a))) < 1e-12) throw ArithmeticException("tan undefined")
                    clean(tan(toRadians(a)))
                }
                "ln" -> {
                    if (a <= 0.0) throw ArithmeticException("ln domain")
                    ln(a)
                }
                "log" -> {
                    if (a <= 0.0) throw ArithmeticException("log domain")
                    log10(a)
                }
                "√" -> {
                    if (a < 0.0) throw ArithmeticException("sqrt domain")
                    sqrt(a)
                }
                else -> throw IllegalArgumentException("Unknown function $name")
            }
        }

        private fun factorial(v: Double): Double {
            if (v < 0.0 || v != floor(v) || v > 170.0) throw ArithmeticException("factorial domain")
            var r = 1.0
            for (i in 2..v.toInt()) r *= i
            return r
        }
    }
}

// ------------------------------------------------------------- display helpers

/** "1234567+8.5" -> "1,234,567+8.5". Digits after '.' or 'E' are left untouched. */
fun formatForDisplay(s: String): String {
    val sb = StringBuilder()
    var i = 0
    while (i < s.length) {
        val c = s[i]
        if (c.isDigit()) {
            val start = i
            while (i < s.length && s[i].isDigit()) i++
            sb.append(groupThousands(s.substring(start, i)))
            if (i < s.length && s[i] == '.') {
                sb.append('.')
                i++
                while (i < s.length && s[i].isDigit()) {
                    sb.append(s[i])
                    i++
                }
            }
            if (i < s.length && s[i] == 'E') {
                sb.append('E')
                i++
                if (i < s.length && (s[i] == '+' || s[i] == '-')) {
                    sb.append(s[i])
                    i++
                }
                while (i < s.length && s[i].isDigit()) {
                    sb.append(s[i])
                    i++
                }
            }
        } else if (c == '.') {
            sb.append('.')
            i++
            while (i < s.length && s[i].isDigit()) {
                sb.append(s[i])
                i++
            }
        } else {
            sb.append(c)
            i++
        }
    }
    return sb.toString()
}

private fun groupThousands(digits: String): String {
    if (digits.length <= 3) return digits
    return digits.reversed().chunked(3).joinToString(",").reversed()
}

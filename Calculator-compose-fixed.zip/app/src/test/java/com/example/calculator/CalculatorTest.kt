package com.example.calculator

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class CalculatorTest {

    private fun eval(expression: String, degrees: Boolean = true): String? =
        Evaluator.evaluate(expression, degrees)?.let { Evaluator.format(it) }

    private fun keys(vararg keys: Key, degrees: Boolean = true): CalculatorState =
        keys.fold(CalculatorState(degrees = degrees)) { state, key -> state.press(key) }

    // ---------------------------------------------------------------- evaluator

    @Test fun precedence() {
        assertEquals("7", eval("1+2×3"))
        assertEquals("2.5", eval("10÷4"))
        assertEquals("512", eval("2^3^2"))
        assertEquals("−4", eval("−2^2"))
        assertEquals("−6", eval("2×−3"))
    }

    @Test fun floatingPointNoise() {
        assertEquals("0.3", eval("0.1+0.2"))
    }

    @Test fun bracketsAndImplicitMultiplication() {
        assertEquals("21", eval("(1+2)(3+4)"))
        assertEquals("5", eval("(2+3"))
        assertEquals("6.28318530718", eval("2π"))
    }

    @Test fun functionsInDegrees() {
        assertEquals("0.5", eval("sin(30)"))
        assertEquals("0.5", eval("cos(60)"))
        assertEquals("1", eval("tan(45)"))
        assertEquals("0", eval("sin(180)"))
        assertEquals("4", eval("√(16)"))
        assertEquals("1", eval("ln(e)"))
        assertEquals("3", eval("log(1000)"))
    }

    @Test fun functionsInRadians() {
        assertEquals("0", eval("sin(π)", degrees = false))
    }

    @Test fun factorialAndPercent() {
        assertEquals("120", eval("5!"))
        assertEquals("0.5", eval("50%"))
    }

    @Test fun invalidInputIsNull() {
        assertNull(eval("1÷0"))
        assertNull(eval("tan(90)"))
        assertNull(eval("√(−1)"))
        assertNull(eval("5)"))
    }

    @Test fun formatting() {
        assertEquals("1E20", Evaluator.format(1e20))
        assertEquals("−0.000000001", Evaluator.format(-1e-9))
        assertEquals("4,584", formatForDisplay("4584"))
        assertEquals("1,234,567.891", formatForDisplay("1234567.891"))
    }

    // ------------------------------------------------------------------ keypad

    @Test fun simpleSum() {
        val s = keys(Key.D2, Key.ADD, Key.D3, Key.EQUALS)
        assertEquals("5", s.mainText)
        assertEquals("2+3 =", s.secondaryText)
        assertEquals(1, s.history.size)
    }

    @Test fun divisionByZeroShowsError() {
        assertEquals("Error", keys(Key.D1, Key.DIV, Key.D0, Key.EQUALS).mainText)
    }

    @Test fun leadingZerosAndSecondDecimalPointAreIgnored() {
        assertEquals("7", keys(Key.D0, Key.D0, Key.D7).mainText)
        assertEquals("1.5", keys(Key.D1, Key.DOT, Key.DOT, Key.D5).mainText)
    }

    @Test fun operatorReplacesPreviousOperator() {
        assertEquals("10", keys(Key.D5, Key.ADD, Key.MUL, Key.D2, Key.EQUALS).mainText)
    }

    @Test fun signToggle() {
        assertEquals("−4", keys(Key.SIGN, Key.D4, Key.EQUALS).mainText)
        assertEquals("4", keys(Key.D4, Key.SIGN, Key.SIGN).mainText)
        assertEquals("25", keys(Key.D5, Key.SIGN, Key.SQUARE, Key.EQUALS).mainText)
    }

    @Test fun continuesFromResultButDigitStartsFresh() {
        assertEquals("6", keys(Key.D2, Key.ADD, Key.D3, Key.EQUALS, Key.ADD, Key.D1, Key.EQUALS).mainText)
        assertEquals("7", keys(Key.D2, Key.ADD, Key.D3, Key.EQUALS, Key.D7).mainText)
    }

    @Test fun squareOfNegativeResult() {
        assertEquals("25", keys(Key.D2, Key.SUB, Key.D7, Key.EQUALS, Key.SQUARE, Key.EQUALS).mainText)
    }

    @Test fun scientificKeys() {
        assertEquals("0.5", keys(Key.SIN, Key.D3, Key.D0, Key.RPAREN, Key.EQUALS).mainText)
        assertEquals("14", keys(Key.D2, Key.LPAREN, Key.D3, Key.ADD, Key.D4, Key.RPAREN, Key.EQUALS).mainText)
        assertEquals("3", keys(Key.SQRT, Key.D9, Key.EQUALS).mainText)
        assertEquals("0.25", keys(Key.D4, Key.RECIPROCAL, Key.EQUALS).mainText)
        assertEquals("1,024", keys(Key.D2, Key.POWER, Key.D1, Key.D0, Key.EQUALS).mainText)
    }

    @Test fun backspace() {
        assertEquals("12", keys(Key.D1, Key.D2, Key.D3, Key.DEL).mainText)
        assertEquals("0", keys(Key.SIN, Key.DEL).mainText)
        assertEquals("0", keys(Key.D1, Key.ADD, Key.D1, Key.EQUALS, Key.DEL).mainText)
    }

    @Test fun allClearKeepsDegreeSetting() {
        val s = keys(Key.ANGLE, Key.D1, Key.ADD, Key.D1, Key.AC)
        assertEquals("0", s.mainText)
        assertEquals(false, s.degrees)
    }
}

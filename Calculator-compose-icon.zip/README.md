# Calculator (Kotlin / Jetpack Compose)

Android calculator with a Standard and a Scientific mode, built from the HTML design mockups.

- **Standard** — AC, ±, %, ÷ × − +, decimal point, delete button in the display
- **Scientific** — brackets, x², √, xʸ, sin/cos/tan, ln/log, π, e, 1/x, n!, Deg/Rad toggle
- **Menu button** — pick the accent color (pink, blue, amber, teal)
- **History button** — recent calculations (kept in memory); tap one to reuse the result

## Build

GitHub: push this project to a repo. `.github/workflows/build.yml` runs the unit tests,
builds the debug APK and uploads it as the `calculator-debug-apk` artifact (Actions tab).
If the repo contains the project `.zip` instead of the loose files, the workflow unpacks it first.

Locally: open the folder in Android Studio, or run `gradle assembleDebug`.
The Gradle wrapper isn't included — run `gradle wrapper` once if you want `./gradlew`.

## Font

The design uses Outfit. The workflow downloads it into `app/src/main/res/font/outfit.ttf`.
Locally, drop a variable `Outfit` TTF there under that name; without it the app uses the system font.

## Icon

Adaptive launcher icon ("Operators": + − × ÷ on yellow) lives in `res/drawable/ic_launcher_foreground.xml`
(also used as the Android 13 themed/monochrome layer) and `res/values/ic_launcher_background.xml`.
`design/` has the standalone SVG and a 512 px PNG for the Play Store listing.

## Layout

```
app/src/main/java/com/example/calculator/
  CalculatorEngine.kt     expression parser + number formatting
  CalculatorState.kt      keys, state, key-press reducer
  CalculatorViewModel.kt
  MainActivity.kt
  ui/                     theme, font loader, CalculatorScreen (all composables)
app/src/test/             unit tests
```

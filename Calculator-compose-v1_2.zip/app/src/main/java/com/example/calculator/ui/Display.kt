package com.example.calculator.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import com.example.calculator.CalculatorState

/**
 * The result window. Only the result is shown (plus the finished expression in small type after
 * "="). Swipe sideways on it to delete digits, long-press to copy the value; the X button deletes
 * one character, and long-pressing it clears everything.
 */
@Composable
internal fun DisplayCard(
    state: CalculatorState,
    maxFont: Float,
    copied: Boolean,
    onDelete: () -> Unit,
    onClear: () -> Unit,
    onCopy: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val skin = LocalPalette.current.skin
    val currentDelete by rememberUpdatedState(onDelete)
    val currentCopy by rememberUpdatedState(onCopy)

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(skin.displayRadius))
            .background(skin.displayBg)
            .pointerInput(Unit) {
                detectTapGestures(onLongPress = { currentCopy() })
            }
            .pointerInput(Unit) {
                val step = 28.dp.toPx()
                var travelled = 0f
                detectHorizontalDragGestures(
                    onDragStart = { travelled = 0f },
                    onHorizontalDrag = { change, dragAmount ->
                        change.consume()
                        travelled += dragAmount
                        while (travelled >= step || travelled <= -step) {
                            currentDelete()
                            travelled -= if (travelled > 0f) step else -step
                        }
                    },
                )
            }
            .padding(20.dp),
        horizontalAlignment = Alignment.End,
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.height(40.dp), contentAlignment = Alignment.CenterStart) {
                CopiedChip(visible = copied)
            }
            CircleIconButton(
                diameter = 40.dp,
                background = Color.Black.copy(alpha = 0.12f),
                description = "Delete last digit",
                onClick = onDelete,
                onLongClick = onClear,
            ) {
                SvgIcon(listOf(CLOSE_ICON), 20.dp, 2.4f, skin.displayInk)
            }
        }

        Column(
            modifier = Modifier.animateContentSize(),
            horizontalAlignment = Alignment.End,
        ) {
            val secondary = state.secondaryText
            if (secondary.isNotEmpty()) {
                Text(
                    text = secondary,
                    fontSize = 20.sp,
                    color = skin.displayInk.copy(alpha = 0.6f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.End,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            AutoSizeText(
                text = state.mainText,
                maxSize = maxFont,
                minSize = 28f,
                color = skin.displayInk,
                pulseKey = if (state.justEvaluated && !state.error) state.lastExpression else null,
            )
        }
    }
}

/**
 * Single-line text that shrinks from [maxSize] down to [minSize] to fit the width (wrapping onto up
 * to three lines below the minimum). Shrinking is instant so text never overflows; growing back
 * when digits are deleted is animated. [pulseKey] gives the text a small springy "pop" whenever it
 * changes to a non-null value (used for a fresh result).
 */
@Composable
private fun AutoSizeText(
    text: String,
    maxSize: Float,
    minSize: Float,
    color: Color,
    pulseKey: Any?,
) {
    val measurer = rememberTextMeasurer()
    val base = LocalTextStyle.current.copy(fontWeight = FontWeight.Medium, letterSpacing = (-0.03).em)
    val pulse = remember { Animatable(1f) }

    LaunchedEffect(pulseKey) {
        if (pulseKey != null) {
            pulse.snapTo(1.045f)
            pulse.animateTo(1f, spring<Float>(dampingRatio = 0.5f, stiffness = 380f))
        }
    }

    BoxWithConstraints(Modifier.fillMaxWidth()) {
        val widthPx = constraints.maxWidth
        val target = remember(text, widthPx, maxSize, base) {
            var s = maxSize
            while (s > minSize &&
                measurer.measure(
                    text = text,
                    style = base.copy(fontSize = s.sp),
                    softWrap = false,
                    maxLines = 1,
                ).size.width > widthPx
            ) {
                s = maxOf(minSize, s * 0.92f)
            }
            s
        }
        val animated by animateFloatAsState(
            targetValue = target,
            animationSpec = spring<Float>(stiffness = 300f),
            label = "resultSize",
        )
        val size = minOf(animated, target)

        Text(
            text = text,
            color = color,
            fontSize = size.sp,
            lineHeight = (size * 1.05f).sp,
            fontWeight = FontWeight.Medium,
            letterSpacing = (-0.03).em,
            textAlign = TextAlign.End,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .fillMaxWidth()
                .graphicsLayer {
                    scaleX = pulse.value
                    scaleY = pulse.value
                    transformOrigin = TransformOrigin(1f, 0.5f)
                },
        )
    }
}

/** Lives at top level so AnimatedVisibility isn't resolved against the surrounding Row's scope. */
@Composable
private fun CopiedChip(visible: Boolean) {
    val skin = LocalPalette.current.skin
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn() + scaleIn(initialScale = 0.8f),
        exit = fadeOut() + scaleOut(targetScale = 0.9f),
    ) {
        Box(
            Modifier
                .clip(RoundedCornerShape(16.dp))
                .background(skin.displayInk.copy(alpha = 0.12f))
                .padding(horizontal = 12.dp, vertical = 6.dp),
        ) {
            Text(
                text = "Copied",
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = skin.displayInk,
            )
        }
    }
}

package com.example.calculator.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.lerp as lerpDp

/**
 * A complete look for the calculator: surfaces, key colors, shapes and four accent colors.
 * The accent (operators, "=") is picked separately from [accents].
 */
@Immutable
class Skin(
    val name: String,
    val light: Boolean,
    val monospace: Boolean,
    val background: Color,
    val headerButton: Color,
    val headerInk: Color,
    val digitKey: Color,
    val digitInk: Color,
    val functionKey: Color,
    val functionInk: Color,
    val sciKey: Color,
    val sciInk: Color,
    val tabTrack: Color,
    val tabSelected: Color,
    val tabInk: Color,
    val tabMuted: Color,
    val displayBg: Color,
    val displayInk: Color,
    val sheet: Color,
    val sheetInk: Color,
    val sheetMuted: Color,
    val divider: Color,
    /** Color blended into a key while a finger is on it. */
    val pressTint: Color,
    /** Operator keys are the accent mixed into this color... */
    val opBase: Color,
    /** ...by this much. */
    val opTint: Float,
    /** Key corner radius as a fraction of the key height. */
    val keyRadius: Float,
    val displayRadius: Dp,
    val accents: List<Color>,
)

/** A skin plus the chosen accent, and the colors derived from the two. */
@Immutable
class Palette(val skin: Skin, val accent: Color) {
    val operatorBg: Color = lerp(skin.opBase, accent, skin.opTint)

    /** Text on top of an accent-colored key: dark on light accents, white on dark ones. */
    val equalsInk: Color = if (accent.luminance() > 0.4f) Color(0xFF140A0E) else Color.White
}

val LocalPalette = staticCompositionLocalOf<Palette> { error("No Palette provided") }

private fun mix(a: Float, b: Float, f: Float) = a + (b - a) * f

fun lerpSkin(a: Skin, b: Skin, f: Float): Skin {
    if (f <= 0f) return a
    if (f >= 1f) return b
    fun c(x: Color, y: Color) = lerp(x, y, f)
    return Skin(
        name = b.name,
        light = if (f < 0.5f) a.light else b.light,
        monospace = if (f < 0.5f) a.monospace else b.monospace,
        background = c(a.background, b.background),
        headerButton = c(a.headerButton, b.headerButton),
        headerInk = c(a.headerInk, b.headerInk),
        digitKey = c(a.digitKey, b.digitKey),
        digitInk = c(a.digitInk, b.digitInk),
        functionKey = c(a.functionKey, b.functionKey),
        functionInk = c(a.functionInk, b.functionInk),
        sciKey = c(a.sciKey, b.sciKey),
        sciInk = c(a.sciInk, b.sciInk),
        tabTrack = c(a.tabTrack, b.tabTrack),
        tabSelected = c(a.tabSelected, b.tabSelected),
        tabInk = c(a.tabInk, b.tabInk),
        tabMuted = c(a.tabMuted, b.tabMuted),
        displayBg = c(a.displayBg, b.displayBg),
        displayInk = c(a.displayInk, b.displayInk),
        sheet = c(a.sheet, b.sheet),
        sheetInk = c(a.sheetInk, b.sheetInk),
        sheetMuted = c(a.sheetMuted, b.sheetMuted),
        divider = c(a.divider, b.divider),
        pressTint = c(a.pressTint, b.pressTint),
        opBase = c(a.opBase, b.opBase),
        opTint = mix(a.opTint, b.opTint, f),
        keyRadius = mix(a.keyRadius, b.keyRadius, f),
        displayRadius = lerpDp(a.displayRadius, b.displayRadius, f),
        accents = b.accents,
    )
}

/** Cross-fades from the previous skin to [target] whenever it changes. */
@Composable
fun rememberAnimatedSkin(target: Skin): Skin {
    var from by remember { mutableStateOf(target) }
    var to by remember { mutableStateOf(target) }
    val progress = remember { Animatable(1f) }
    LaunchedEffect(target) {
        if (target !== to) {
            from = lerpSkin(from, to, progress.value)
            to = target
            progress.snapTo(0f)
            progress.animateTo(1f, tween(380))
        }
    }
    val fraction = progress.value
    return remember(from, to, fraction) { lerpSkin(from, to, fraction) }
}

// -------------------------------------------------------------------------- the skins

/** The original look: black, a yellow display, pink accent. */
val Scrapbook = Skin(
    name = "Scrapbook",
    light = false,
    monospace = false,
    background = Color(0xFF000000),
    headerButton = Color(0xFF1A1A1A),
    headerInk = Color.White,
    digitKey = Color(0xFF1A1A1A),
    digitInk = Color.White,
    functionKey = Color(0xFF2A2A2A),
    functionInk = Color.White,
    sciKey = Color(0xFF161616),
    sciInk = Color.White,
    tabTrack = Color(0xFF111111),
    tabSelected = Color(0xFF262626),
    tabInk = Color.White,
    tabMuted = Color(0xFF8E8E8E),
    displayBg = Color(0xFFFFC40D),
    displayInk = Color(0xFF17120A),
    sheet = Color(0xFF111111),
    sheetInk = Color.White,
    sheetMuted = Color(0xFF8E8E8E),
    divider = Color(0xFF1A1A1A),
    pressTint = Color.White,
    opBase = Color(0xFF111111),
    opTint = 0.16f,
    keyRadius = 0.34f,
    displayRadius = 32.dp,
    accents = listOf(Color(0xFFFF8FB1), Color(0xFF4DA3FF), Color(0xFFF5B92E), Color(0xFF3FD8D0)),
)

/** Warm light paper with a charcoal display. */
val Paper = Skin(
    name = "Paper",
    light = true,
    monospace = false,
    background = Color(0xFFF3F0E8),
    headerButton = Color(0xFFFFFFFF),
    headerInk = Color(0xFF1B1B1B),
    digitKey = Color(0xFFFFFFFF),
    digitInk = Color(0xFF1B1B1B),
    functionKey = Color(0xFFE4DFD3),
    functionInk = Color(0xFF1B1B1B),
    sciKey = Color(0xFFECE8DE),
    sciInk = Color(0xFF1B1B1B),
    tabTrack = Color(0xFFE4DFD3),
    tabSelected = Color(0xFFFFFFFF),
    tabInk = Color(0xFF1B1B1B),
    tabMuted = Color(0xFF77726A),
    displayBg = Color(0xFF1E1C19),
    displayInk = Color(0xFFF6F2E8),
    sheet = Color(0xFFF9F7F2),
    sheetInk = Color(0xFF1B1B1B),
    sheetMuted = Color(0xFF77726A),
    divider = Color(0xFFE4DFD3),
    pressTint = Color.Black,
    opBase = Color(0xFFF3F0E8),
    opTint = 0.12f,
    keyRadius = 0.34f,
    displayRadius = 32.dp,
    accents = listOf(Color(0xFFC93A22), Color(0xFF2458E6), Color(0xFFA86400), Color(0xFF00775A)),
)

/** Deep navy with a periwinkle display. */
val Midnight = Skin(
    name = "Midnight",
    light = false,
    monospace = false,
    background = Color(0xFF070B18),
    headerButton = Color(0xFF131A33),
    headerInk = Color(0xFFF2F5FF),
    digitKey = Color(0xFF131A33),
    digitInk = Color(0xFFF2F5FF),
    functionKey = Color(0xFF1D2750),
    functionInk = Color(0xFFF2F5FF),
    sciKey = Color(0xFF0F1630),
    sciInk = Color(0xFFF2F5FF),
    tabTrack = Color(0xFF0D1326),
    tabSelected = Color(0xFF1D2750),
    tabInk = Color(0xFFF2F5FF),
    tabMuted = Color(0xFF8D97BD),
    displayBg = Color(0xFF6F8CFF),
    displayInk = Color(0xFF060A24),
    sheet = Color(0xFF0D1326),
    sheetInk = Color(0xFFF2F5FF),
    sheetMuted = Color(0xFF8D97BD),
    divider = Color(0xFF131A33),
    pressTint = Color.White,
    opBase = Color(0xFF0D1326),
    opTint = 0.18f,
    keyRadius = 0.4f,
    displayRadius = 36.dp,
    accents = listOf(Color(0xFFFFC857), Color(0xFF5EEAD4), Color(0xFFFF8FB1), Color(0xFFB39DFF)),
)

/** Dark green with a mint display and pill-shaped keys. */
val Mint = Skin(
    name = "Mint",
    light = false,
    monospace = false,
    background = Color(0xFF06100C),
    headerButton = Color(0xFF0F201A),
    headerInk = Color(0xFFE8FFF4),
    digitKey = Color(0xFF0F201A),
    digitInk = Color(0xFFE8FFF4),
    functionKey = Color(0xFF18362A),
    functionInk = Color(0xFFE8FFF4),
    sciKey = Color(0xFF0B1913),
    sciInk = Color(0xFFE8FFF4),
    tabTrack = Color(0xFF0B1913),
    tabSelected = Color(0xFF18362A),
    tabInk = Color(0xFFE8FFF4),
    tabMuted = Color(0xFF86A596),
    displayBg = Color(0xFF9BF2C8),
    displayInk = Color(0xFF06231A),
    sheet = Color(0xFF0B1913),
    sheetInk = Color(0xFFE8FFF4),
    sheetMuted = Color(0xFF86A596),
    divider = Color(0xFF0F201A),
    pressTint = Color.White,
    opBase = Color(0xFF0B1913),
    opTint = 0.18f,
    keyRadius = 0.46f,
    displayRadius = 40.dp,
    accents = listOf(Color(0xFFD4F562), Color(0xFFFF8A6B), Color(0xFFFFD84D), Color(0xFF6CC8FF)),
)

/** Olive-black with an LCD-green display, square keys and a monospaced font. */
val Retro = Skin(
    name = "Retro",
    light = false,
    monospace = true,
    background = Color(0xFF12140D),
    headerButton = Color(0xFF22261A),
    headerInk = Color(0xFFC9D68A),
    digitKey = Color(0xFF22261A),
    digitInk = Color(0xFFC9D68A),
    functionKey = Color(0xFF2F3420),
    functionInk = Color(0xFFC9D68A),
    sciKey = Color(0xFF1A1D12),
    sciInk = Color(0xFFC9D68A),
    tabTrack = Color(0xFF1A1D12),
    tabSelected = Color(0xFF2F3420),
    tabInk = Color(0xFFC9D68A),
    tabMuted = Color(0xFF7C8553),
    displayBg = Color(0xFFB7C77A),
    displayInk = Color(0xFF1B2410),
    sheet = Color(0xFF1A1D12),
    sheetInk = Color(0xFFC9D68A),
    sheetMuted = Color(0xFF7C8553),
    divider = Color(0xFF22261A),
    pressTint = Color(0xFFE9F5B8),
    opBase = Color(0xFF1A1D12),
    opTint = 0.2f,
    keyRadius = 0.14f,
    displayRadius = 12.dp,
    accents = listOf(Color(0xFFFFB000), Color(0xFFFF5A3C), Color(0xFFA8E05F), Color(0xFF52D6E8)),
)

val Skins: List<Skin> = listOf(Scrapbook, Paper, Midnight, Mint, Retro)

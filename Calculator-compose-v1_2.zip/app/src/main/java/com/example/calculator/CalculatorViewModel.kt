package com.example.calculator

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel

class CalculatorViewModel(application: Application) : AndroidViewModel(application) {

    private val store = SettingsStore(
        application.getSharedPreferences("calculator", Context.MODE_PRIVATE),
    )

    var state by mutableStateOf(
        CalculatorState(history = store.loadHistory(), degrees = store.loadDegrees()),
    )
        private set

    var settings by mutableStateOf(store.load())
        private set

    fun onKey(key: Key) {
        val before = state
        val after = before.press(key)
        state = after
        if (after.history != before.history) store.saveHistory(after.history)
        if (after.degrees != before.degrees) store.saveDegrees(after.degrees)
    }

    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        settings = transform(settings)
        store.save(settings)
    }

    /** Puts a history result back on the display so the user can keep calculating with it. */
    fun useHistory(entry: HistoryEntry) {
        state = state.copy(
            expression = entry.result,
            lastExpression = entry.expression,
            justEvaluated = true,
            error = false,
        )
    }

    fun clearHistory() {
        state = state.copy(history = emptyList())
        store.saveHistory(emptyList())
    }
}

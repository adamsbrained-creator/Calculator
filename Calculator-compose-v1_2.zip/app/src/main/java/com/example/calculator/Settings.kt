package com.example.calculator

import android.content.SharedPreferences

/** Everything the user can change in the settings sheet (plus the Standard/Scientific switch). */
data class AppSettings(
    val skin: Int = 0,
    val accent: Int = 0,
    val scientific: Boolean = false,
    val haptics: Boolean = true,
    val slideToType: Boolean = true,
)

/** Keeps settings, history and the angle mode in SharedPreferences. */
class SettingsStore(private val prefs: SharedPreferences) {

    fun load(): AppSettings = AppSettings(
        skin = prefs.getInt("skin", 0),
        accent = prefs.getInt("accent", 0),
        scientific = prefs.getBoolean("scientific", false),
        haptics = prefs.getBoolean("haptics", true),
        slideToType = prefs.getBoolean("slide", true),
    )

    fun save(settings: AppSettings) {
        prefs.edit()
            .putInt("skin", settings.skin)
            .putInt("accent", settings.accent)
            .putBoolean("scientific", settings.scientific)
            .putBoolean("haptics", settings.haptics)
            .putBoolean("slide", settings.slideToType)
            .apply()
    }

    fun loadHistory(): List<HistoryEntry> =
        HistoryCodec.decode(prefs.getString("history", "") ?: "")

    fun saveHistory(history: List<HistoryEntry>) {
        prefs.edit().putString("history", HistoryCodec.encode(history)).apply()
    }

    fun loadDegrees(): Boolean = prefs.getBoolean("degrees", true)

    fun saveDegrees(degrees: Boolean) {
        prefs.edit().putBoolean("degrees", degrees).apply()
    }
}

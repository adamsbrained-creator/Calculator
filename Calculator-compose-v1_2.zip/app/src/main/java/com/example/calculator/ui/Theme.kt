package com.example.calculator.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

/** Material theme that follows the current skin (the skins themselves are drawn by hand). */
@Composable
fun CalculatorTheme(skin: Skin, content: @Composable () -> Unit) {
    val scheme = if (skin.light) {
        lightColorScheme(
            background = skin.background,
            surface = skin.background,
            surfaceContainer = skin.sheet,
            onBackground = skin.headerInk,
            onSurface = skin.headerInk,
        )
    } else {
        darkColorScheme(
            background = skin.background,
            surface = skin.background,
            surfaceContainer = skin.sheet,
            onBackground = skin.headerInk,
            onSurface = skin.headerInk,
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

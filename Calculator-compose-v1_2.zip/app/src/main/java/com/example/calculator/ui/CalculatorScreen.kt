package com.example.calculator.ui

import android.view.HapticFeedbackConstants
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import com.example.calculator.AppSettings
import com.example.calculator.CalculatorState
import com.example.calculator.HistoryEntry
import com.example.calculator.Key
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalculatorScreen(
    state: CalculatorState,
    settings: AppSettings,
    onSettingsChange: ((AppSettings) -> AppSettings) -> Unit,
    onKey: (Key) -> Unit,
    onUseHistory: (HistoryEntry) -> Unit,
    onClearHistory: () -> Unit,
) {
    // The skin and accent cross-fade when they change.
    val targetSkin = Skins[settings.skin.coerceIn(0, Skins.lastIndex)]
    val skin = rememberAnimatedSkin(targetSkin)
    val targetAccent = targetSkin.accents[settings.accent.coerceIn(0, targetSkin.accents.lastIndex)]
    val accent by animateColorAsState(
        targetValue = targetAccent,
        animationSpec = tween<Color>(durationMillis = 320),
        label = "accent",
    )
    val palette = remember(skin, accent) { Palette(skin, accent) }

    val outfit = rememberOutfit()
    val fontFamily = if (skin.monospace) FontFamily.Monospace else outfit

    var showHistory by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var copied by remember { mutableStateOf(false) }
    val clipboard = LocalClipboardManager.current
    val view = LocalView.current

    LaunchedEffect(copied) {
        if (copied) {
            delay(1400)
            copied = false
        }
    }

    val haptics = settings.haptics
    val onDelete: () -> Unit = {
        if (haptics) view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        onKey(Key.DEL)
    }
    val onClear: () -> Unit = {
        if (haptics) view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        onKey(Key.AC)
    }
    val onCopy: () -> Unit = {
        val text = state.copyText
        if (text.isNotEmpty()) {
            clipboard.setText(AnnotatedString(text))
            copied = true
            if (haptics) view.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        }
    }
    val onScientific: (Boolean) -> Unit = { value -> onSettingsChange { it.copy(scientific = value) } }

    CalculatorTheme(skin) {
        CompositionLocalProvider(
            LocalPalette provides palette,
            LocalTextStyle provides TextStyle(fontFamily = fontFamily),
        ) {
            BoxWithConstraints(
                Modifier
                    .fillMaxSize()
                    .background(skin.background)
                    .windowInsetsPadding(WindowInsets.safeDrawing),
            ) {
                if (maxWidth > maxHeight) {
                    LandscapeLayout(
                        state = state,
                        settings = settings,
                        copied = copied,
                        onKey = onKey,
                        onDelete = onDelete,
                        onClear = onClear,
                        onCopy = onCopy,
                        onScientific = onScientific,
                        onSettings = { showSettings = true },
                        onHistory = { showHistory = true },
                    )
                } else {
                    PortraitLayout(
                        state = state,
                        settings = settings,
                        copied = copied,
                        available = maxHeight - 20.dp,
                        onKey = onKey,
                        onDelete = onDelete,
                        onClear = onClear,
                        onCopy = onCopy,
                        onScientific = onScientific,
                        onSettings = { showSettings = true },
                        onHistory = { showHistory = true },
                    )
                }
            }

            if (showHistory) {
                ModalBottomSheet(
                    onDismissRequest = { showHistory = false },
                    containerColor = skin.sheet,
                    contentColor = skin.sheetInk,
                ) {
                    HistoryContent(
                        history = state.history,
                        onPick = {
                            onUseHistory(it)
                            showHistory = false
                        },
                        onClear = onClearHistory,
                    )
                }
            }

            if (showSettings) {
                ModalBottomSheet(
                    onDismissRequest = { showSettings = false },
                    sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
                    containerColor = skin.sheet,
                    contentColor = skin.sheetInk,
                ) {
                    SettingsContent(settings = settings, onChange = onSettingsChange)
                }
            }
        }
    }
}

// -------------------------------------------------------------------- portrait

@Composable
private fun PortraitLayout(
    state: CalculatorState,
    settings: AppSettings,
    copied: Boolean,
    available: Dp,
    onKey: (Key) -> Unit,
    onDelete: () -> Unit,
    onClear: () -> Unit,
    onCopy: () -> Unit,
    onScientific: (Boolean) -> Unit,
    onSettings: () -> Unit,
    onHistory: () -> Unit,
) {
    val scientific = settings.scientific

    // On short screens shrink the key rows a little so the display keeps some room.
    val fixedChrome = 44.dp + 12.dp + 38.dp + 32.dp + (if (scientific) 12.dp else 0.dp)
    val gridHeight =
        if (scientific) 40.dp * 3 + 8.dp * 2 + 62.dp * 5 + 10.dp * 4
        else 76.dp * 5 + 12.dp * 4
    val targetScale = ((available - fixedChrome - 150.dp) / gridHeight).coerceIn(0.72f, 1f)

    // The pad and the function grid glide to their new sizes when the mode changes.
    val padRow by animateDpAsState(
        targetValue = (if (scientific) 62.dp else 76.dp) * targetScale,
        label = "padRow",
    )
    val padGap by animateDpAsState(targetValue = if (scientific) 10.dp else 12.dp, label = "padGap")
    val sciRow by animateDpAsState(targetValue = 40.dp * targetScale, label = "sciRow")
    val sciKeyRows = remember(state.degrees) { sciRows(state.degrees) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Header(compact = false, onSettings = onSettings, onHistory = onHistory)

        ModeTabs(
            scientific = scientific,
            onChange = onScientific,
            modifier = Modifier.padding(top = 12.dp),
        )

        DisplayCard(
            state = state,
            maxFont = if (scientific) 56f else 76f,
            copied = copied,
            onDelete = onDelete,
            onClear = onClear,
            onCopy = onCopy,
            modifier = Modifier
                .weight(1f)
                .padding(vertical = 16.dp),
        )

        AnimatedVisibility(
            visible = scientific,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut(),
        ) {
            Column {
                Keypad(
                    rows = sciKeyRows,
                    columns = 5,
                    gap = 8.dp,
                    haptics = settings.haptics,
                    slideEnabled = settings.slideToType,
                    onKey = onKey,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(sciRow * 3 + 8.dp * 2),
                )
                Spacer(Modifier.height(12.dp))
            }
        }

        Keypad(
            rows = KeypadRows,
            columns = 4,
            gap = padGap,
            haptics = settings.haptics,
            slideEnabled = settings.slideToType,
            onKey = onKey,
            modifier = Modifier
                .fillMaxWidth()
                .height(padRow * 5 + padGap * 4),
        )
    }
}

// ------------------------------------------------------------------- landscape

/**
 * Two panes: the display (with the scientific functions under it) on the left, the main pad on the
 * right, which stretches to use the full height.
 */
@Composable
private fun LandscapeLayout(
    state: CalculatorState,
    settings: AppSettings,
    copied: Boolean,
    onKey: (Key) -> Unit,
    onDelete: () -> Unit,
    onClear: () -> Unit,
    onCopy: () -> Unit,
    onScientific: (Boolean) -> Unit,
    onSettings: () -> Unit,
    onHistory: () -> Unit,
) {
    val scientific = settings.scientific
    val sciKeyRows = remember(state.degrees) { sciRows(state.degrees) }

    Row(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Column(
            modifier = Modifier
                .weight(if (scientific) 1.05f else 0.9f)
                .fillMaxHeight(),
        ) {
            Header(compact = true, onSettings = onSettings, onHistory = onHistory)

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                contentAlignment = Alignment.Center,
            ) {
                ModeTabs(scientific = scientific, onChange = onScientific)
            }

            DisplayCard(
                state = state,
                maxFont = if (scientific) 48f else 60f,
                copied = copied,
                onDelete = onDelete,
                onClear = onClear,
                onCopy = onCopy,
                modifier = Modifier
                    .weight(1f)
                    .padding(vertical = 10.dp),
            )

            AnimatedVisibility(
                visible = scientific,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut(),
            ) {
                Column {
                    Keypad(
                        rows = sciKeyRows,
                        columns = 5,
                        gap = 6.dp,
                        haptics = settings.haptics,
                        slideEnabled = settings.slideToType,
                        onKey = onKey,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(112.dp),
                    )
                    Spacer(Modifier.height(4.dp))
                }
            }
        }

        Keypad(
            rows = KeypadRows,
            columns = 4,
            gap = 10.dp,
            haptics = settings.haptics,
            slideEnabled = settings.slideToType,
            onKey = onKey,
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight(),
        )
    }
}

// ---------------------------------------------------------------------- chrome

@Composable
private fun Header(compact: Boolean, onSettings: () -> Unit, onHistory: () -> Unit) {
    val skin = LocalPalette.current.skin
    val size = if (compact) 40.dp else 44.dp
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(size),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CircleIconButton(size, skin.headerButton, "Settings", onSettings) {
            SvgIcon(listOf(MENU_ICON), 22.dp, 2f, skin.headerInk)
        }

        Text(
            text = "Calculator",
            fontSize = 22.sp,
            fontWeight = FontWeight.Medium,
            letterSpacing = (-0.01).em,
            color = skin.headerInk,
        )

        CircleIconButton(size, skin.headerButton, "History", onHistory) {
            SvgIcon(HISTORY_ICON, 22.dp, 2f, skin.headerInk)
        }
    }
}

@Composable
private fun ModeTabs(
    scientific: Boolean,
    onChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
) {
    val skin = LocalPalette.current.skin
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(19.dp))
            .background(skin.tabTrack)
            .padding(3.dp),
    ) {
        ModeTab("Standard", selected = !scientific) { onChange(false) }
        ModeTab("Scientific", selected = scientific) { onChange(true) }
    }
}

@Composable
private fun ModeTab(label: String, selected: Boolean, onClick: () -> Unit) {
    val skin = LocalPalette.current.skin
    val background by animateColorAsState(
        targetValue = if (selected) skin.tabSelected else Color.Transparent,
        animationSpec = tween<Color>(durationMillis = 220),
        label = "tabBackground",
    )
    val ink by animateColorAsState(
        targetValue = if (selected) skin.tabInk else skin.tabMuted,
        animationSpec = tween<Color>(durationMillis = 220),
        label = "tabInk",
    )
    Box(
        modifier = Modifier
            .height(32.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(background)
            .clickable(role = Role.Tab, onClick = onClick)
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = label,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            color = ink,
        )
    }
}

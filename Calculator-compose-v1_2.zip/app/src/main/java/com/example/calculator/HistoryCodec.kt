package com.example.calculator

/** Turns the history list into a string and back, so it can be kept in SharedPreferences. */
object HistoryCodec {

    fun encode(history: List<HistoryEntry>): String =
        history.joinToString("\n") { it.expression + "\t" + it.result }

    fun decode(text: String): List<HistoryEntry> =
        text.lineSequence()
            .mapNotNull { line ->
                val tab = line.indexOf('\t')
                if (tab <= 0 || tab == line.lastIndex) null
                else HistoryEntry(line.substring(0, tab), line.substring(tab + 1))
            }
            .toList()
}

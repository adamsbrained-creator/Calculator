package com.example.calculator

/** Every button on both keypads. Digits come first so Key.entries[n] is digit n. */
enum class Key(val digit: Char? = null) {
    D0('0'), D1('1'), D2('2'), D3('3'), D4('4'), D5('5'), D6('6'), D7('7'), D8('8'), D9('9'),
    DOT, ADD, SUB, MUL, DIV, EQUALS, AC, DEL, SIGN, PERCENT,
    LPAREN, RPAREN, SQUARE, SQRT, POWER, SIN, COS, TAN, LN, LOG,
    PI, E, RECIPROCAL, FACTORIAL, ANGLE
}

data class HistoryEntry(val expression: String, val result: String)

data class CalculatorState(
    val expression: String = "",
    /** The expression that produced the current result; shown small above it after '='. */
    val lastExpression: String = "",
    val justEvaluated: Boolean = false,
    val error: Boolean = false,
    val degrees: Boolean = true,
    val history: List<HistoryEntry> = emptyList(),
) {
    val mainText: String
        get() = when {
            error -> "Error"
            expression.isEmpty() -> "0"
            else -> formatForDisplay(expression)
        }

    /** What long-pressing the display copies: plain ASCII, no thousands separators. */
    val copyText: String
        get() = when {
            error -> ""
            expression.isEmpty() -> "0"
            else -> expression.replace('−', '-').replace('×', '*').replace('÷', '/')
        }

    val secondaryText: String
        get() = when {
            error -> formatForDisplay(expression)
            justEvaluated -> formatForDisplay(lastExpression) + " ="
            else -> ""
        }
}

private const val MAX_DIGITS = 15
private const val MAX_LENGTH = 200
private const val OPERATORS = "+−×÷^"
private val OPERATOR_CHARS = charArrayOf('+', '−', '×', '÷', '^')

/** Keys that keep working on the previous result instead of starting a new calculation. */
private val CONTINUING_KEYS = setOf(
    Key.ADD, Key.SUB, Key.MUL, Key.DIV, Key.POWER,
    Key.PERCENT, Key.FACTORIAL, Key.SQUARE, Key.RECIPROCAL,
)

/** Chunks removed as one unit by the backspace button. */
private val DELETE_TOKENS = listOf("sin(", "cos(", "tan(", "log(", "ln(", "√(", "^(−1)")

fun CalculatorState.press(key: Key): CalculatorState {
    when (key) {
        Key.AC -> return copy(expression = "", lastExpression = "", justEvaluated = false, error = false)
        Key.ANGLE -> return copy(degrees = !degrees)
        Key.EQUALS -> return evaluate()
        Key.DEL -> return backspace()
        else -> Unit
    }
    val live = if (error) copy(error = false) else this
    return if (key == Key.SIGN) live.toggleSign() else live.input(key)
}

// ------------------------------------------------------------------- helpers

private fun String.endsWithOperand(): Boolean =
    isNotEmpty() && (last().isDigit() || last() in ".πe)!%")

/** Operands that are not plain number literals need an explicit '×' before a new number. */
private fun String.needsMultiply(): Boolean = isNotEmpty() && last() in "πe)!%"

private fun String.trailingNumberStart(): Int {
    var i = length
    while (i > 0 && (this[i - 1].isDigit() || this[i - 1] == '.')) i--
    return i
}

private fun String.unclosedParens(): Int = count { it == '(' } - count { it == ')' }

private fun String.precededByExponent(start: Int): Boolean =
    start > 0 && (this[start - 1] == 'E' || (start > 1 && this[start - 1] == '-' && this[start - 2] == 'E'))

/**
 * Before applying x², 1/x… to a negative number typed as "−5" (or "2×−5"), wrap it as "(−5)"
 * so the power applies to the whole number, like a phone calculator would.
 */
private fun CalculatorState.groupedBase(base: String): String {
    if (justEvaluated) return if (base.startsWith("−")) "($base)" else base
    val end = base.length
    val start = base.trailingNumberStart()
    if (start in 1 until end && base[start - 1] == '−' &&
        (start - 1 == 0 || base[start - 2] in "+−×÷^(")
    ) {
        return base.substring(0, start - 1) + "(" + base.substring(start - 1) + ")"
    }
    return base
}

private fun applyOperator(base: String, op: Char): String? {
    if (base.isEmpty()) return if (op == '−') "−" else null
    val last = base.last()
    if (last in OPERATORS) {
        // "5×" then "−" -> unary minus: "5×−"
        if (op == '−' && last in "×÷^") return base + op
        val stripped = base.trimEnd(*OPERATOR_CHARS)
        if (stripped.isEmpty()) return if (op == '−') "−" else null
        if (stripped.last() == '(') return if (op == '−') stripped + op else null
        return stripped + op
    }
    if (last == '(') return if (op == '−') base + op else null
    return base + op
}

private fun appendDigit(base: String, d: Char): String? {
    if (base.needsMultiply()) return base + "×" + d
    val start = base.trailingNumberStart()
    val run = base.substring(start)
    if (run == "0" && !base.precededByExponent(start)) return base.substring(0, start) + d
    if (run.count { it.isDigit() } >= MAX_DIGITS) return null
    return base + d
}

private fun appendDecimal(base: String): String? {
    if (base.needsMultiply()) return base + "×0."
    val start = base.trailingNumberStart()
    val run = base.substring(start)
    return when {
        base.precededByExponent(start) -> null
        run.contains('.') -> null
        run.isEmpty() -> base + "0."
        else -> base + "."
    }
}

private fun withPrefix(base: String, addition: String): String =
    (if (base.endsWithOperand()) base + "×" else base) + addition

// ----------------------------------------------------------------- reducers

private fun CalculatorState.input(key: Key): CalculatorState {
    val base = if (justEvaluated && key !in CONTINUING_KEYS) "" else expression
    val next: String? = when (key) {
        Key.ADD -> applyOperator(base, '+')
        Key.SUB -> applyOperator(base, '−')
        Key.MUL -> applyOperator(base, '×')
        Key.DIV -> applyOperator(base, '÷')
        Key.POWER -> applyOperator(base, '^')
        Key.LPAREN -> if (base.endsWithOperand()) base + "×(" else base + "("
        Key.RPAREN ->
            if (base.unclosedParens() > 0 && base.endsWithOperand()) base + ")" else null
        Key.SIN -> withPrefix(base, "sin(")
        Key.COS -> withPrefix(base, "cos(")
        Key.TAN -> withPrefix(base, "tan(")
        Key.LN -> withPrefix(base, "ln(")
        Key.LOG -> withPrefix(base, "log(")
        Key.SQRT -> withPrefix(base, "√(")
        Key.PI -> withPrefix(base, "π")
        Key.E -> withPrefix(base, "e")
        Key.SQUARE -> if (base.endsWithOperand()) groupedBase(base) + "^2" else null
        Key.RECIPROCAL -> if (base.endsWithOperand()) groupedBase(base) + "^(−1)" else null
        Key.FACTORIAL -> if (base.endsWithOperand()) base + "!" else null
        Key.PERCENT -> if (base.endsWithOperand()) base + "%" else null
        Key.DOT -> appendDecimal(base)
        else -> key.digit?.let { appendDigit(base, it) }
    }
    return if (next == null || next.length > MAX_LENGTH) this
    else copy(expression = next, justEvaluated = false)
}

private fun CalculatorState.toggleSign(): CalculatorState {
    if (justEvaluated) {
        if (expression == "0") return this
        val flipped = if (expression.startsWith("−")) expression.drop(1) else "−" + expression
        return copy(expression = flipped)
    }
    val base = expression
    val start = base.trailingNumberStart()
    val next: String = when {
        start < base.length -> {
            val unary = start > 0 && base[start - 1] == '−' &&
                (start - 1 == 0 || base[start - 2] in "+−×÷^(")
            if (unary) base.removeRange(start - 1, start)
            else base.substring(0, start) + "−" + base.substring(start)
        }
        base.isEmpty() || base.last() in "+×÷^(" -> base + "−"
        else -> return this
    }
    return copy(expression = next)
}

private fun CalculatorState.backspace(): CalculatorState {
    if (justEvaluated) {
        return copy(expression = "", lastExpression = "", justEvaluated = false, error = false)
    }
    if (error) return copy(error = false)
    if (expression.isEmpty()) return this
    val chunk = DELETE_TOKENS.firstOrNull { expression.endsWith(it) } ?: expression.takeLast(1)
    return copy(expression = expression.dropLast(chunk.length))
}

private fun CalculatorState.evaluate(): CalculatorState {
    if (expression.isEmpty() || justEvaluated) return this
    val cleaned = expression.trimEnd(*OPERATOR_CHARS)
    if (cleaned.isEmpty()) return this
    val value = Evaluator.evaluate(cleaned, degrees) ?: return copy(error = true)
    val result = Evaluator.format(value)
    return copy(
        expression = result,
        lastExpression = cleaned,
        justEvaluated = true,
        error = false,
        history = (listOf(HistoryEntry(cleaned, result)) + history).take(50),
    )
}

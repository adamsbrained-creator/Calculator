package com.example.calculator.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp

// Icon paths on a 24x24 viewBox, the same ones the mockups use.
internal const val MENU_ICON = "M4 7h16M4 12h16M4 17h10"
internal val HISTORY_ICON = listOf("M3 12a9 9 0 1 0 3-6.7L3 8", "M3 3v5h5", "M12 7v5l3 2")
internal const val CLOSE_ICON = "M6.5 6.5l11 11M17.5 6.5l-11 11"

/** Draws stroked SVG paths authored on a 24x24 viewBox, exactly like the mockup's icons. */
@Composable
internal fun SvgIcon(paths: List<String>, iconSize: Dp, strokeWidth: Float, color: Color) {
    val parsed: List<Path> = remember(paths) {
        paths.map { PathParser().parsePathString(it).toPath() }
    }
    Canvas(Modifier.size(iconSize)) {
        val k = this.size.width / 24f
        withTransform({ scale(scaleX = k, scaleY = k, pivot = Offset.Zero) }) {
            parsed.forEach { path ->
                drawPath(
                    path = path,
                    color = color,
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round, join = StrokeJoin.Round),
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun CircleIconButton(
    diameter: Dp,
    background: Color,
    description: String,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null,
    content: @Composable () -> Unit,
) {
    Box(
        modifier = Modifier
            .size(diameter)
            .clip(CircleShape)
            .background(background)
            .combinedClickable(role = Role.Button, onLongClick = onLongClick, onClick = onClick)
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center,
    ) { content() }
}

package com.example.calculator

import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Pure (no Compose, no Android) touch logic for a keypad, so it can be unit tested.
 *
 *  - [PadGeometry] knows where every key is and maps a finger position to a key. The gaps between
 *    keys belong to the nearest key, so there are no dead zones.
 *  - [PadTouchTracker] follows every finger separately (multi-touch), fires keys on touch-down for
 *    instant response, lets a finger slide across keys to enter them, and lets it lift on "=" to
 *    calculate.
 */

/** Keys that fire when the finger lifts on them, so a stray touch can't wipe the display. */
val Key.isDeferred: Boolean
    get() = this == Key.AC || this == Key.EQUALS

private val SLIDE_ENTRY_KEYS = setOf(
    Key.DOT, Key.ADD, Key.SUB, Key.MUL, Key.DIV, Key.POWER,
    Key.LPAREN, Key.RPAREN, Key.PI, Key.E,
)

/** Keys a sliding finger enters when it passes over them: digits, dot, operators, brackets, π, e. */
val Key.isSlideEntry: Boolean
    get() = digit != null || this in SLIDE_ENTRY_KEYS

class PadGeometry(val cells: List<Cell>, private val tolerance: Float) {

    class Cell(val left: Float, val top: Float, val right: Float, val bottom: Float) {
        val width: Float get() = right - left
        val height: Float get() = bottom - top
    }

    /** The key under (x, y). A point in a gap belongs to the nearest key; far outside is null. */
    fun cellAt(x: Float, y: Float): Int? {
        var best = -1
        var bestDistance = Float.MAX_VALUE
        for (i in cells.indices) {
            val c = cells[i]
            val dx = max(max(c.left - x, x - c.right), 0f)
            val dy = max(max(c.top - y, y - c.bottom), 0f)
            val d = dx * dx + dy * dy
            if (d < bestDistance) {
                best = i
                bestDistance = d
            }
        }
        if (best < 0) return null
        return if (sqrt(bestDistance) <= tolerance) best else null
    }

    /** True when (x, y) is well inside the key, not near its edge ([fraction] of each side is excluded). */
    fun isDeepInside(index: Int, x: Float, y: Float, fraction: Float): Boolean {
        val c = cells.getOrNull(index) ?: return false
        val ix = c.width * fraction
        val iy = c.height * fraction
        return x >= c.left + ix && x <= c.right - ix && y >= c.top + iy && y <= c.bottom - iy
    }

    companion object {
        /**
         * A grid with [columns] equal columns and one row per entry of [spans]; each entry lists the
         * column span of every key in that row (so a "0" key spanning two columns is `2`).
         */
        fun grid(spans: List<List<Int>>, columns: Int, width: Float, height: Float, gap: Float): PadGeometry {
            if (spans.isEmpty() || columns <= 0) return PadGeometry(emptyList(), gap)
            val rowHeight = (height - gap * (spans.size - 1)) / spans.size
            val colWidth = (width - gap * (columns - 1)) / columns
            val cells = ArrayList<Cell>()
            spans.forEachIndexed { r, row ->
                var col = 0
                val top = r * (rowHeight + gap)
                row.forEach { span ->
                    val left = col * (colWidth + gap)
                    val w = colWidth * span + gap * (span - 1)
                    cells.add(Cell(left, top, left + w, top + rowHeight))
                    col += span
                }
            }
            return PadGeometry(cells, max(gap, 8f))
        }
    }
}

enum class Trigger {
    /** A plain press. */
    Tap,

    /** A finger slid onto the key. */
    Slide,

    /** A finger that slid across keys was lifted on "=". */
    Commit,
}

class PadTouchTracker(var onTrigger: (Key, Trigger) -> Unit = { _, _ -> }) {

    var geometry: PadGeometry = PadGeometry(emptyList(), 0f)
    var keys: List<Key> = emptyList()
    var slideEnabled: Boolean = true

    /** Share of each key side a finger must cross before a slide counts as entering that key. */
    var deepFraction: Float = 0.2f

    /** Fast swipes are sampled along the path at this spacing (px) so no key is skipped. */
    var sampleStep: Float = 8f

    private class Pointer(var cell: Int, val startCell: Int, var x: Float, var y: Float) {
        /** Still resting on the key it started on. */
        var armed = true

        /** Has entered at least one other key. */
        var slid = false
    }

    private val pointers = HashMap<Long, Pointer>()

    fun down(id: Long, x: Float, y: Float) {
        val cell = geometry.cellAt(x, y) ?: return
        val key = keys.getOrNull(cell) ?: return
        pointers[id] = Pointer(cell, cell, x, y)
        if (!key.isDeferred) onTrigger(key, Trigger.Tap)
    }

    fun move(id: Long, x: Float, y: Float) {
        val p = pointers[id] ?: return
        val dx = x - p.x
        val dy = y - p.y
        val distance = sqrt(dx * dx + dy * dy)
        val steps = max(1, ceil(distance / sampleStep).toInt())
        for (i in 1..steps) {
            val t = i / steps.toFloat()
            step(p, p.x + dx * t, p.y + dy * t)
        }
        p.x = x
        p.y = y
    }

    private fun step(p: Pointer, x: Float, y: Float) {
        val here = geometry.cellAt(x, y)
        if (p.armed && (here == null || (here != p.startCell && geometry.isDeepInside(here, x, y, deepFraction)))) {
            p.armed = false
        }
        if (!slideEnabled) return
        val next = here ?: return
        if (next == p.cell || !geometry.isDeepInside(next, x, y, deepFraction)) return
        p.cell = next
        p.slid = true
        val key = keys.getOrNull(next) ?: return
        if (key.isSlideEntry) onTrigger(key, Trigger.Slide)
    }

    fun up(id: Long) {
        val p = pointers.remove(id) ?: return
        val startKey = keys.getOrNull(p.startCell) ?: return
        if (startKey.isDeferred) {
            if (p.armed) onTrigger(startKey, Trigger.Tap)
            return
        }
        if (slideEnabled && p.slid && keys.getOrNull(p.cell) == Key.EQUALS) {
            onTrigger(Key.EQUALS, Trigger.Commit)
        }
    }

    fun cancel(id: Long) {
        pointers.remove(id)
    }

    fun cancelAll() {
        pointers.clear()
    }

    /** The key each finger is currently on, for drawing pressed states. */
    fun pressedCells(): Set<Int> {
        if (pointers.isEmpty()) return emptySet()
        val result = HashSet<Int>()
        for (p in pointers.values) result.add(p.cell)
        return result
    }
}

package com.example.calculator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.calculator.ui.CalculatorScreen
import com.example.calculator.ui.Skins

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )

        setContent {
            val viewModel: CalculatorViewModel = viewModel()
            val settings = viewModel.settings

            // Light skins need dark status and navigation bar icons.
            val lightSkin = Skins[settings.skin.coerceIn(0, Skins.lastIndex)].light
            val view = LocalView.current
            SideEffect {
                val controller = WindowCompat.getInsetsController(window, view)
                controller.isAppearanceLightStatusBars = lightSkin
                controller.isAppearanceLightNavigationBars = lightSkin
            }

            CalculatorScreen(
                state = viewModel.state,
                settings = settings,
                onSettingsChange = viewModel::updateSettings,
                onKey = viewModel::onKey,
                onUseHistory = viewModel::useHistory,
                onClearHistory = viewModel::clearHistory,
            )
        }
    }
}

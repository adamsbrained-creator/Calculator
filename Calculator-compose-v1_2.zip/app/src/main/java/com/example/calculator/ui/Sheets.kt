package com.example.calculator.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.calculator.AppSettings
import com.example.calculator.HistoryEntry
import com.example.calculator.formatForDisplay

// -------------------------------------------------------------------- settings

@Composable
internal fun SettingsContent(
    settings: AppSettings,
    onChange: ((AppSettings) -> AppSettings) -> Unit,
) {
    val palette = LocalPalette.current
    val skin = palette.skin
    val selectedSkin = Skins[settings.skin.coerceIn(0, Skins.lastIndex)]

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp)
            .navigationBarsPadding()
            .padding(bottom = 20.dp),
    ) {
        Text("Settings", fontSize = 22.sp, fontWeight = FontWeight.Medium, color = skin.sheetInk)

        SectionLabel("Skin")
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Skins.forEachIndexed { index, option ->
                SkinChip(
                    option = option,
                    selected = index == settings.skin,
                    ring = palette.accent,
                    onClick = {
                        onChange { it.copy(skin = index, accent = it.accent.coerceIn(0, option.accents.lastIndex)) }
                    },
                )
            }
        }

        SectionLabel("Accent")
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            selectedSkin.accents.forEachIndexed { index, color ->
                Box(
                    Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(color)
                        .then(
                            if (index == settings.accent) Modifier.border(3.dp, skin.sheetInk, CircleShape)
                            else Modifier,
                        )
                        .clickable(role = Role.RadioButton) { onChange { it.copy(accent = index) } },
                )
            }
        }

        SectionLabel("Input")
        ToggleRow(
            title = "Slide to type",
            subtitle = "Drag across keys to enter them. Lift on = to calculate.",
            checked = settings.slideToType,
            onCheckedChange = { value -> onChange { it.copy(slideToType = value) } },
        )
        ToggleRow(
            title = "Haptic feedback",
            subtitle = null,
            checked = settings.haptics,
            onCheckedChange = { value -> onChange { it.copy(haptics = value) } },
        )
    }
}

@Composable
private fun SectionLabel(text: String) {
    val skin = LocalPalette.current.skin
    Text(
        text = text,
        fontSize = 14.sp,
        fontWeight = FontWeight.Medium,
        color = skin.sheetMuted,
        modifier = Modifier.padding(top = 20.dp, bottom = 10.dp),
    )
}

/** A small preview of a skin: its display and a few keys. */
@Composable
private fun SkinChip(option: Skin, selected: Boolean, ring: Color, onClick: () -> Unit) {
    val skin = LocalPalette.current.skin
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier = Modifier
            .clip(shape)
            .clickable(role = Role.RadioButton, onClick = onClick)
            .padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Column(
            modifier = Modifier
                .size(width = 84.dp, height = 104.dp)
                .clip(shape)
                .background(option.background)
                .border(
                    width = if (selected) 3.dp else 1.dp,
                    color = if (selected) ring else skin.divider,
                    shape = shape,
                )
                .padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(5.dp),
        ) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(30.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(option.displayBg),
            )
            MiniKeys(option.functionKey, option.accents[0])
            MiniKeys(option.digitKey, option.accents[0])
            MiniKeys(option.digitKey, option.accents[0])
        }
        Text(
            text = option.name,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            color = skin.sheetInk,
            modifier = Modifier.padding(top = 6.dp),
        )
    }
}

@Composable
private fun MiniKeys(key: Color, accent: Color) {
    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        repeat(3) {
            Box(Modifier.size(width = 15.dp, height = 12.dp).clip(RoundedCornerShape(5.dp)).background(key))
        }
        Box(Modifier.size(width = 15.dp, height = 12.dp).clip(RoundedCornerShape(5.dp)).background(accent))
    }
}

@Composable
private fun ToggleRow(
    title: String,
    subtitle: String?,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
) {
    val palette = LocalPalette.current
    val skin = palette.skin
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(role = Role.Switch) { onCheckedChange(!checked) }
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 17.sp, fontWeight = FontWeight.Medium, color = skin.sheetInk)
            if (subtitle != null) {
                Text(subtitle, fontSize = 14.sp, color = skin.sheetMuted)
            }
        }
        Switch(
            checked = checked,
            onCheckedChange = null,
            colors = SwitchDefaults.colors(
                checkedThumbColor = palette.equalsInk,
                checkedTrackColor = palette.accent,
                checkedBorderColor = Color.Transparent,
                uncheckedThumbColor = skin.sheetMuted,
                uncheckedTrackColor = skin.functionKey,
                uncheckedBorderColor = Color.Transparent,
            ),
        )
    }
}

// --------------------------------------------------------------------- history

@Composable
internal fun HistoryContent(
    history: List<HistoryEntry>,
    onPick: (HistoryEntry) -> Unit,
    onClear: () -> Unit,
) {
    val palette = LocalPalette.current
    val skin = palette.skin
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .navigationBarsPadding()
            .padding(bottom = 16.dp),
    ) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("History", fontSize = 22.sp, fontWeight = FontWeight.Medium, color = skin.sheetInk)
            if (history.isNotEmpty()) {
                TextButton(onClick = onClear) { Text("Clear", color = palette.accent, fontSize = 16.sp) }
            }
        }

        if (history.isEmpty()) {
            Text(
                "No calculations yet",
                color = skin.sheetMuted,
                fontSize = 16.sp,
                modifier = Modifier.padding(vertical = 24.dp),
            )
        } else {
            LazyColumn(Modifier.heightIn(max = 420.dp)) {
                items(history) { entry ->
                    Column(Modifier.fillMaxWidth()) {
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .clickable(role = Role.Button) { onPick(entry) }
                                .padding(vertical = 12.dp),
                            horizontalAlignment = Alignment.End,
                        ) {
                            Text(
                                formatForDisplay(entry.expression) + " =",
                                color = skin.sheetMuted,
                                fontSize = 16.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                            Text(
                                formatForDisplay(entry.result),
                                color = skin.sheetInk,
                                fontSize = 30.sp,
                                fontWeight = FontWeight.Medium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                            )
                        }
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .height(1.dp)
                                .background(skin.divider),
                        )
                    }
                }
            }
        }
    }
}

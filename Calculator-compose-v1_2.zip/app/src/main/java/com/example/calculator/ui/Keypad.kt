package com.example.calculator.ui

import android.os.Build
import android.view.HapticFeedbackConstants
import android.view.View
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.BaselineShift
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.calculator.Key
import com.example.calculator.PadGeometry
import com.example.calculator.PadTouchTracker
import com.example.calculator.Trigger

// ---------------------------------------------------------------- layout specs

internal enum class Kind { Function, Digit, Operator, Equals, Sci, SciAccent }

internal class Spec(
    val label: AnnotatedString,
    val key: Key,
    val kind: Kind,
    val description: String? = null,
    val small: Boolean = false, // AC uses a smaller font than ± and %
    val span: Int = 1,
)

private fun t(text: String) = AnnotatedString(text)

private fun digit(n: Int) = Spec(t(n.toString()), Key.entries[n], Kind.Digit)

/** The main 4 x 5 pad. */
internal val KeypadRows: List<List<Spec>> = listOf(
    listOf(
        Spec(t("AC"), Key.AC, Kind.Function, "All clear", small = true),
        Spec(t("±"), Key.SIGN, Kind.Function, "Plus minus"),
        Spec(t("%"), Key.PERCENT, Kind.Function, "Percent"),
        Spec(t("÷"), Key.DIV, Kind.Operator, "Divide"),
    ),
    listOf(digit(7), digit(8), digit(9), Spec(t("×"), Key.MUL, Kind.Operator, "Multiply")),
    listOf(digit(4), digit(5), digit(6), Spec(t("−"), Key.SUB, Kind.Operator, "Subtract")),
    listOf(digit(1), digit(2), digit(3), Spec(t("+"), Key.ADD, Kind.Operator, "Add")),
    listOf(
        Spec(t("0"), Key.D0, Kind.Digit, span = 2),
        Spec(t("."), Key.DOT, Kind.Digit, "Decimal point"),
        Spec(t("="), Key.EQUALS, Kind.Equals, "Equals"),
    ),
)

private val PowerLabel = buildAnnotatedString {
    append("x")
    withStyle(SpanStyle(baselineShift = BaselineShift.Superscript, fontSize = 11.sp)) { append("y") }
}

/** The extra 5 x 3 function grid of the scientific mode. */
internal fun sciRows(degrees: Boolean): List<List<Spec>> = listOf(
    listOf(
        Spec(t("("), Key.LPAREN, Kind.Sci, "Open bracket"),
        Spec(t(")"), Key.RPAREN, Kind.Sci, "Close bracket"),
        Spec(t("x²"), Key.SQUARE, Kind.Sci, "Square"),
        Spec(t("√"), Key.SQRT, Kind.Sci, "Square root"),
        Spec(PowerLabel, Key.POWER, Kind.Sci, "Power"),
    ),
    listOf(
        Spec(t("sin"), Key.SIN, Kind.Sci),
        Spec(t("cos"), Key.COS, Kind.Sci),
        Spec(t("tan"), Key.TAN, Kind.Sci),
        Spec(t("ln"), Key.LN, Kind.Sci, "Natural log"),
        Spec(t("log"), Key.LOG, Kind.Sci, "Log base 10"),
    ),
    listOf(
        Spec(t("π"), Key.PI, Kind.Sci, "Pi"),
        Spec(t("e"), Key.E, Kind.Sci, "Euler number"),
        Spec(t("1/x"), Key.RECIPROCAL, Kind.Sci, "Reciprocal"),
        Spec(t("n!"), Key.FACTORIAL, Kind.Sci, "Factorial"),
        Spec(
            t(if (degrees) "Deg" else "Rad"),
            Key.ANGLE,
            Kind.SciAccent,
            if (degrees) "Angle mode, degrees" else "Angle mode, radians",
        ),
    ),
)

// ---------------------------------------------------------------------- keypad

/**
 * A grid of keys that fills [modifier]'s size. Touch is handled for the whole grid at once, not per
 * key: every finger is tracked on its own (so fast two-thumb typing works), keys fire the moment a
 * finger lands, the gaps between keys count as part of the nearest key, and a finger sliding across
 * keys enters them one after another. See [PadTouchTracker] for the rules.
 */
@Composable
internal fun Keypad(
    rows: List<List<Spec>>,
    columns: Int,
    gap: Dp,
    haptics: Boolean,
    slideEnabled: Boolean,
    onKey: (Key) -> Unit,
    modifier: Modifier = Modifier,
) {
    val density = LocalDensity.current
    val view = LocalView.current
    val latestOnKey by rememberUpdatedState(onKey)
    val latestHaptics by rememberUpdatedState(haptics)

    val tracker = remember {
        PadTouchTracker { key, trigger ->
            if (latestHaptics) view.performKeyHaptic(key, trigger)
            latestOnKey(key)
        }
    }
    var pressed by remember { mutableStateOf(emptySet<Int>()) }

    val spans = remember(rows) { rows.map { row -> row.map { it.span } } }
    val keys = remember(rows) { rows.flatten().map { it.key } }
    val indexed = remember(rows) {
        var next = 0
        rows.map { row -> row.map { spec -> spec to next++ } }
    }

    BoxWithConstraints(modifier) {
        val widthPx = constraints.maxWidth.toFloat()
        val heightPx = constraints.maxHeight.toFloat()
        val gapPx = with(density) { gap.toPx() }
        val geometry = remember(spans, columns, widthPx, heightPx, gapPx) {
            PadGeometry.grid(spans, columns, widthPx, heightPx, gapPx)
        }
        SideEffect {
            tracker.geometry = geometry
            tracker.keys = keys
            tracker.slideEnabled = slideEnabled
            tracker.sampleStep = with(density) { 6.dp.toPx() }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    awaitPointerEventScope {
                        while (true) {
                            val event = awaitPointerEvent()
                            for (change in event.changes) {
                                val id = change.id.value
                                if (change.pressed && !change.previousPressed) {
                                    tracker.down(id, change.position.x, change.position.y)
                                } else if (change.pressed) {
                                    tracker.move(id, change.position.x, change.position.y)
                                } else if (change.previousPressed) {
                                    tracker.up(id)
                                }
                            }
                            val now = tracker.pressedCells()
                            if (now != pressed) pressed = now
                        }
                    }
                },
            verticalArrangement = Arrangement.spacedBy(gap),
        ) {
            indexed.forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                    row.forEach { (spec, index) ->
                        val cell = geometry.cells.getOrNull(index)
                        if (cell != null) {
                            PadKey(
                                spec = spec,
                                pressed = index in pressed,
                                width = with(density) { cell.width.toDp() },
                                height = with(density) { cell.height.toDp() },
                                onActivate = { latestOnKey(spec.key) },
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PadKey(
    spec: Spec,
    pressed: Boolean,
    width: Dp,
    height: Dp,
    onActivate: () -> Unit,
) {
    val palette = LocalPalette.current
    val skin = palette.skin

    val background: Color
    val ink: Color
    val ratio: Float // font size as a fraction of the key height
    val weight: FontWeight
    when (spec.kind) {
        Kind.Function -> {
            background = skin.functionKey
            ink = skin.functionInk
            ratio = if (spec.small) 0.29f else 0.34f
            weight = if (spec.small) FontWeight.Medium else FontWeight.Normal
        }
        Kind.Digit -> {
            background = skin.digitKey
            ink = skin.digitInk
            ratio = 0.39f
            weight = FontWeight.Normal
        }
        Kind.Operator -> {
            background = palette.operatorBg
            ink = palette.accent
            ratio = 0.45f
            weight = FontWeight.Normal
        }
        Kind.Equals -> {
            background = palette.accent
            ink = palette.equalsInk
            ratio = 0.47f
            weight = FontWeight.Medium
        }
        Kind.Sci -> {
            background = skin.sciKey
            ink = skin.sciInk
            ratio = 0.40f
            weight = FontWeight.Medium
        }
        Kind.SciAccent -> {
            background = palette.operatorBg
            ink = palette.accent
            ratio = 0.40f
            weight = FontWeight.Medium
        }
    }

    // A quick brighten on touch-down that fades out slowly, plus a small springy squash.
    val press by animateFloatAsState(
        targetValue = if (pressed) 1f else 0f,
        animationSpec = tween<Float>(durationMillis = if (pressed) 40 else 260),
        label = "keyPress",
    )
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.93f else 1f,
        animationSpec = spring<Float>(dampingRatio = 0.5f, stiffness = 600f),
        label = "keyScale",
    )

    val fontSize = minOf(height.value * ratio, width.value * 0.5f).sp
    val description = spec.description ?: spec.label.text

    Box(
        modifier = Modifier
            .size(width, height)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clip(RoundedCornerShape(height * skin.keyRadius))
            .background(lerp(background, skin.pressTint, 0.22f * press))
            .semantics {
                role = Role.Button
                contentDescription = description
                // Touch is handled by the grid, so screen readers get their own click action.
                onClick {
                    onActivate()
                    true
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = spec.label,
            color = ink,
            fontSize = fontSize,
            fontWeight = weight,
            maxLines = 1,
        )
    }
}

private fun View.performKeyHaptic(key: Key, trigger: Trigger) {
    val constant = when {
        trigger == Trigger.Slide -> HapticFeedbackConstants.CLOCK_TICK
        trigger == Trigger.Commit || key == Key.EQUALS ->
            if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.CONFIRM
            else HapticFeedbackConstants.KEYBOARD_TAP
        else -> HapticFeedbackConstants.KEYBOARD_TAP
    }
    performHapticFeedback(constant)
}

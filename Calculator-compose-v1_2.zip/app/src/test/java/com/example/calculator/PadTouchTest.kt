package com.example.calculator

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PadTouchTest {

    // The standard pad: 4 columns x 5 rows, "0" spans two columns.
    private val spans = listOf(
        listOf(1, 1, 1, 1), listOf(1, 1, 1, 1), listOf(1, 1, 1, 1), listOf(1, 1, 1, 1), listOf(2, 1, 1),
    )
    private val padKeys = listOf(
        Key.AC, Key.SIGN, Key.PERCENT, Key.DIV,
        Key.D7, Key.D8, Key.D9, Key.MUL,
        Key.D4, Key.D5, Key.D6, Key.SUB,
        Key.D1, Key.D2, Key.D3, Key.ADD,
        Key.D0, Key.DOT, Key.EQUALS,
    )

    // 400 x 500 pad, 10 px gaps -> keys are 92.5 x 92 px.
    private val geometry = PadGeometry.grid(spans, columns = 4, width = 400f, height = 500f, gap = 10f)

    private class Recorder {
        val events = ArrayList<Pair<Key, Trigger>>()
        val keys get() = events.map { it.first }
    }

    private fun tracker(rec: Recorder, slide: Boolean = true) = PadTouchTracker { key, trigger ->
        rec.events.add(key to trigger)
    }.also {
        it.geometry = geometry
        it.keys = padKeys
        it.slideEnabled = slide
    }

    private fun centre(key: Key): Pair<Float, Float> {
        val c = geometry.cells[padKeys.indexOf(key)]
        return (c.left + c.right) / 2 to (c.top + c.bottom) / 2
    }

    private fun PadTouchTracker.downOn(id: Long, key: Key) = centre(key).let { down(id, it.first, it.second) }
    private fun PadTouchTracker.moveTo(id: Long, key: Key) = centre(key).let { move(id, it.first, it.second) }

    // ----------------------------------------------------------------- geometry

    @Test fun cellsMatchTheGrid() {
        assertEquals(19, geometry.cells.size)
        val zero = geometry.cells[padKeys.indexOf(Key.D0)]
        assertEquals(0f, zero.left, 0.01f)
        assertEquals(195f, zero.right, 0.01f)          // spans two columns and the gap between them
        val equals = geometry.cells[padKeys.indexOf(Key.EQUALS)]
        assertEquals(400f, equals.right, 0.01f)
        assertEquals(500f, equals.bottom, 0.01f)
    }

    @Test fun gapsBelongToTheNearestKey() {
        // 5 px right of the "7" key's right edge, inside the 10 px gap between 7 and 8.
        val seven = geometry.cells[padKeys.indexOf(Key.D7)]
        val inGap = geometry.cellAt(seven.right + 3f, (seven.top + seven.bottom) / 2)
        assertNotNull(inGap)
        assertTrue(padKeys[inGap!!] == Key.D7 || padKeys[inGap] == Key.D8)
    }

    @Test fun farOutsideIsNoKey() {
        assertNull(geometry.cellAt(-200f, -200f))
        assertNull(geometry.cellAt(900f, 250f))
    }

    // ---------------------------------------------------------------------- taps

    @Test fun tapFiresOnTouchDown() {
        val rec = Recorder()
        val t = tracker(rec)
        t.downOn(1, Key.D5)
        assertEquals(listOf(Key.D5), rec.keys)          // before the finger lifts
        t.up(1)
        assertEquals(listOf(Key.D5), rec.keys)          // and only once
    }

    @Test fun equalsAndAcFireOnLift() {
        val rec = Recorder()
        val t = tracker(rec)
        t.downOn(1, Key.EQUALS)
        assertTrue(rec.events.isEmpty())
        t.up(1)
        assertEquals(listOf(Key.EQUALS to Trigger.Tap), rec.events)

        rec.events.clear()
        t.downOn(2, Key.AC)
        assertTrue(rec.events.isEmpty())
        t.up(2)
        assertEquals(listOf(Key.AC to Trigger.Tap), rec.events)
    }

    @Test fun acIsCancelledByDraggingAway() {
        val rec = Recorder()
        val t = tracker(rec)
        t.downOn(1, Key.AC)
        t.moveTo(1, Key.D7)
        t.up(1)
        assertTrue(Key.AC !in rec.keys)
    }

    @Test fun acIsCancelledByDraggingAwayEvenWithSlideOff() {
        val rec = Recorder()
        val t = tracker(rec, slide = false)
        t.downOn(1, Key.AC)
        t.moveTo(1, Key.D5)
        t.up(1)
        assertTrue(rec.events.isEmpty())
    }

    @Test fun sloppyTapOnAcStillCounts() {
        val rec = Recorder()
        val t = tracker(rec)
        val ac = geometry.cells[padKeys.indexOf(Key.AC)]
        t.down(1, ac.left + 20f, ac.top + 20f)
        t.move(1, ac.right + 4f, ac.top + 22f)           // drifts into the gap, not into the next key
        t.up(1)
        assertEquals(listOf(Key.AC), rec.keys)
    }

    // -------------------------------------------------------------------- sliding

    @Test fun slidingAcrossDigitsEntersThemInOrder() {
        val rec = Recorder()
        val t = tracker(rec)
        t.downOn(1, Key.D1)
        t.moveTo(1, Key.D2)
        t.moveTo(1, Key.D3)
        t.up(1)
        assertEquals(listOf(Key.D1, Key.D2, Key.D3), rec.keys)
        assertEquals(listOf(Trigger.Tap, Trigger.Slide, Trigger.Slide), rec.events.map { it.second })
    }

    @Test fun slidingBuildsTheNumber() {
        val rec = Recorder()
        val t = tracker(rec)
        t.downOn(1, Key.D1)
        t.moveTo(1, Key.D2)
        t.moveTo(1, Key.D3)
        t.moveTo(1, Key.D6)
        t.up(1)
        val state = rec.keys.fold(CalculatorState()) { s, k -> s.press(k) }
        assertEquals("1,236", state.mainText)
    }

    @Test fun aFastSwipeDoesNotSkipTheKeyInTheMiddle() {
        val rec = Recorder()
        val t = tracker(rec)
        t.downOn(1, Key.D7)
        t.moveTo(1, Key.D9)                              // one big jump straight over the 8
        assertEquals(listOf(Key.D7, Key.D8, Key.D9), rec.keys)
    }

    @Test fun diagonalSwipeEntersEveryKeyOnThePath() {
        val rec = Recorder()
        val t = tracker(rec)
        t.downOn(1, Key.D7)
        t.moveTo(1, Key.D5)
        t.moveTo(1, Key.D3)
        assertEquals(listOf(Key.D7, Key.D5, Key.D3), rec.keys)
    }

    @Test fun wigglingInsideAKeyDoesNotRepeatIt() {
        val rec = Recorder()
        val t = tracker(rec)
        val c = geometry.cells[padKeys.indexOf(Key.D5)]
        t.down(1, (c.left + c.right) / 2, (c.top + c.bottom) / 2)
        repeat(20) { i -> t.move(1, c.left + 30f + i, c.top + 30f + (i % 5)) }
        assertEquals(listOf(Key.D5), rec.keys)
    }

    @Test fun edgeOfTheNeighbourDoesNotCount() {
        val rec = Recorder()
        val t = tracker(rec)
        t.downOn(1, Key.D4)
        val four = geometry.cells[padKeys.indexOf(Key.D4)]
        // slightly into the next key, but still near its edge
        t.move(1, four.right + 10f + 4f, (four.top + four.bottom) / 2)
        assertEquals(listOf(Key.D4), rec.keys)
    }

    @Test fun slidingBackReEntersTheKey() {
        val rec = Recorder()
        val t = tracker(rec)
        t.downOn(1, Key.D1)
        t.moveTo(1, Key.D2)
        t.moveTo(1, Key.D1)
        assertEquals(listOf(Key.D1, Key.D2, Key.D1), rec.keys)
    }

    @Test fun slidingOverFunctionKeysDoesNotPressThem() {
        val rec = Recorder()
        val t = tracker(rec)
        t.downOn(1, Key.D7)
        t.moveTo(1, Key.SIGN)
        t.moveTo(1, Key.PERCENT)
        t.moveTo(1, Key.D9)
        assertEquals(listOf(Key.D7, Key.D9), rec.keys)
    }

    @Test fun liftingOnEqualsAfterASlideCalculates() {
        val rec = Recorder()
        val t = tracker(rec)
        // 9 -> × -> 6 -> 3 -> + -> =   (every step is a neighbouring key, so nothing is crossed on the way)
        t.downOn(1, Key.D9)
        t.moveTo(1, Key.MUL)
        t.moveTo(1, Key.D6)
        t.moveTo(1, Key.D3)
        t.moveTo(1, Key.ADD)
        t.moveTo(1, Key.EQUALS)
        assertEquals(listOf(Key.D9, Key.MUL, Key.D6, Key.D3, Key.ADD), rec.keys)
        assertTrue(Key.EQUALS !in rec.keys)             // sliding over "=" alone does nothing
        t.up(1)
        assertEquals(Key.EQUALS to Trigger.Commit, rec.events.last())
        val state = rec.keys.fold(CalculatorState()) { s, k -> s.press(k) }
        assertEquals("567", state.mainText)             // 9 × 63, trailing + dropped
    }

    @Test fun slidingPastEqualsAndBackDoesNotCalculate() {
        val rec = Recorder()
        val t = tracker(rec)
        t.downOn(1, Key.D3)
        t.moveTo(1, Key.ADD)
        t.moveTo(1, Key.EQUALS)
        t.moveTo(1, Key.ADD)                             // came back off "=" before lifting
        t.up(1)
        assertTrue(Key.EQUALS !in rec.keys)
    }

    @Test fun liftingOnEqualsWithoutSlidingNeedsAProperTap() {
        val rec = Recorder()
        val t = tracker(rec)
        t.downOn(1, Key.D5)
        t.up(1)
        t.downOn(2, Key.EQUALS)
        t.up(2)
        assertEquals(listOf(Key.D5, Key.EQUALS), rec.keys)
        assertEquals(Trigger.Tap, rec.events.last().second)
    }

    @Test fun slideCanBeSwitchedOff() {
        val rec = Recorder()
        val t = tracker(rec, slide = false)
        t.downOn(1, Key.D1)
        t.moveTo(1, Key.D2)
        t.moveTo(1, Key.D3)
        t.up(1)
        assertEquals(listOf(Key.D1), rec.keys)
    }

    // ----------------------------------------------------------------- multi-touch

    @Test fun fingersAreTrackedSeparately() {
        val rec = Recorder()
        val t = tracker(rec)
        t.downOn(1, Key.D1)
        t.downOn(2, Key.D2)                              // second finger lands while the first is down
        assertEquals(setOf(padKeys.indexOf(Key.D1), padKeys.indexOf(Key.D2)), t.pressedCells())
        t.up(1)
        t.downOn(3, Key.D3)
        t.up(2)
        t.up(3)
        assertEquals(listOf(Key.D1, Key.D2, Key.D3), rec.keys)
        assertTrue(t.pressedCells().isEmpty())
    }

    @Test fun movingOneFingerDoesNotAffectTheOther() {
        val rec = Recorder()
        val t = tracker(rec)
        t.downOn(1, Key.D4)
        t.downOn(2, Key.D8)
        t.moveTo(1, Key.D5)
        t.moveTo(1, Key.D6)
        t.up(2)
        t.up(1)
        assertEquals(listOf(Key.D4, Key.D8, Key.D5, Key.D6), rec.keys)
    }

    @Test fun touchOutsideThePadIsIgnored() {
        val rec = Recorder()
        val t = tracker(rec)
        t.down(1, -300f, 900f)
        t.move(1, 100f, 100f)
        t.up(1)
        assertTrue(rec.events.isEmpty())
    }

    @Test fun cancelForgetsTheFinger() {
        val rec = Recorder()
        val t = tracker(rec)
        t.downOn(1, Key.EQUALS)
        t.cancel(1)
        t.up(1)
        assertTrue(rec.events.isEmpty())
        assertTrue(t.pressedCells().isEmpty())
    }
}

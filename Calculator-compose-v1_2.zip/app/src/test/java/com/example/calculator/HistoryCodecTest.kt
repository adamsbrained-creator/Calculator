package com.example.calculator

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class HistoryCodecTest {

    @Test fun roundTrip() {
        val history = listOf(
            HistoryEntry("2+3", "5"),
            HistoryEntry("sin(30)×√(16)", "2"),
            HistoryEntry("1÷3", "0.333333333333"),
        )
        assertEquals(history, HistoryCodec.decode(HistoryCodec.encode(history)))
    }

    @Test fun emptyAndGarbage() {
        assertTrue(HistoryCodec.decode("").isEmpty())
        assertTrue(HistoryCodec.decode("no tab here\n\t\nx\t").isEmpty())
    }

    @Test fun badLinesAreSkippedGoodOnesKept() {
        val decoded = HistoryCodec.decode("1+1\t2\nbroken\n3×3\t9")
        assertEquals(listOf(HistoryEntry("1+1", "2"), HistoryEntry("3×3", "9")), decoded)
    }

    @Test fun copyTextIsPlainAscii() {
        val state = CalculatorState(expression = "−1234.5")
        assertEquals("-1234.5", state.copyText)
        assertEquals("6*3/2", CalculatorState(expression = "6×3÷2").copyText)
        assertEquals("0", CalculatorState().copyText)
        assertEquals("", CalculatorState(expression = "1÷0", error = true).copyText)
    }
}

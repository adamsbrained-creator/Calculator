# Calculator (Kotlin / Jetpack Compose)

Android calculator with Standard and Scientific modes, five skins, slide-to-type and a landscape layout.

## Features

- **Standard** — AC, ±, %, ÷ × − +, decimal point
- **Scientific** — brackets, x², √, xʸ, sin/cos/tan, ln/log, π, e, 1/x, n!, Deg/Rad toggle
- **Slide to type** — put a finger down on a key and drag across others: every key you cross is entered.
  Lift on `=` to calculate. `AC` and `=` need a proper touch-and-lift so a sloppy swipe never wipes your work.
  Can be switched off in Settings.
- **Multi-touch** — several fingers at once, each tracked on its own. Gaps between keys belong to the nearest key, so there are no dead zones.
- **Skins** — Scrapbook, Paper, Midnight, Mint, Retro, each with four accent colors (Settings, top-left button). Changing skin cross-fades.
- **Landscape** — two panes: display and mode switch on the left, keypad on the right (scientific keys sit under the display).
- **Display gestures** — swipe left/right on the result to delete digits, long-press to copy, X button deletes (long-press clears).
- **History** — kept between launches; tap an entry to reuse the result.
- **Persistence** — skin, accent, mode, haptics, slide-to-type, history and Deg/Rad survive restarts.
- **Haptics** — light tick on press, a different one when sliding onto a key and on `=`.
- **TalkBack** — every key is exposed as a normal clickable control.

## Build

GitHub: push this project to a repo. `.github/workflows/build.yml` runs the unit tests,
builds the debug APK and uploads it as the `calculator-debug-apk` artifact (Actions tab).
If the repo contains the project `.zip` instead of the loose files, the workflow unpacks it first.

Locally: open the folder in Android Studio, or run `gradle assembleDebug`.
The Gradle wrapper isn't included — run `gradle wrapper` once if you want `./gradlew`.

## Font

The design uses Outfit. The workflow downloads it into `app/src/main/res/font/outfit.ttf`.
Locally, drop a variable `Outfit` TTF there under that name; without it the app uses the system font.

## Icon

Adaptive launcher icon ("Midnight": two overlapping circles, periwinkle and amber, on black):

- `res/drawable/ic_launcher_foreground.xml` – the circles (108dp canvas, everything inside the 66dp safe zone)
- `res/values/ic_launcher_background.xml` – the black background color
- `res/drawable/ic_launcher_monochrome.xml` – Android 13 themed-icon layer (overlap cut out so it still reads as two shapes)

`design/` has the standalone SVG (`icon-midnight.svg`) and a 512 px PNG for the Play Store listing
(`play-store-icon-512.png`). The earlier yellow "Operators" PNG is kept as `play-store-icon-operators-512.png`.

## Layout

```
app/src/main/java/com/example/calculator/
  CalculatorEngine.kt     expression parser + number formatting
  CalculatorState.kt      keys, state, key-press reducer
  CalculatorViewModel.kt  state + settings, saves to SharedPreferences
  Settings.kt             AppSettings + SettingsStore
  HistoryCodec.kt         history <-> string
  PadTouch.kt             touch logic: hit testing, sliding, multi-touch (pure Kotlin, unit tested)
  MainActivity.kt
  ui/
    Skins.kt              Skin / Palette data, the five skins, cross-fade
    Theme.kt, Fonts.kt
    Keypad.kt             the keypad: one pointer handler for the whole pad, per-key press animation
    Display.kt            result card, swipe/long-press gestures, auto-sizing text
    Sheets.kt             settings and history sheets
    CalculatorScreen.kt   portrait and landscape layouts
app/src/test/             unit tests (engine, state, touch tracker, history codec)
```

`PadTouch.kt` has no Android or Compose imports on purpose: it is the part to read first if you
want to understand how sliding works, and it is the part covered by `PadTouchTest`.

## Roadmap ideas

- Unit converter as a third tab
- Memory keys (M+, M−, MR)
- Live preview of the result while typing
- Tip / split-the-bill mode
- Home-screen widget
- More skins (adding one = one new `Skin(...)` entry in `Skins.kt`)
